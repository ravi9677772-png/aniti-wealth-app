import React from 'react';
import { Target, Calendar, TrendingUp } from 'lucide-react';
import { formatINR } from '../hooks/useCurrency';

interface GoalCardProps {
  id: number;
  name: string;
  type: string;
  targetAmount: number;   // paise
  currentAmount: number;  // paise
  targetDate?: string;
  monthlyContribution?: number;
  priority?: string;
  onEdit?: () => void;
  onDelete?: () => void;
}

export function GoalCard({
  name,
  targetAmount,
  currentAmount,
  targetDate,
  monthlyContribution,
  priority,
  onEdit,
  onDelete,
}: GoalCardProps) {
  const progress = targetAmount > 0 ? Math.min(100, Math.round((currentAmount / targetAmount) * 100)) : 0;
  const remaining = Math.max(0, targetAmount - currentAmount);

  const getPriorityBadge = () => {
    if (priority === 'high') return 'bg-rose-100 text-rose-700 dark:bg-rose-950/50 dark:text-rose-400';
    if (priority === 'low') return 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-400';
    return 'bg-amber-100 text-amber-700 dark:bg-amber-950/50 dark:text-amber-400';
  };

  return (
    <div className="p-4 md:p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between space-y-4 hover:shadow-md transition">
      <div>
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-teal-50 dark:bg-teal-950/40 text-teal-600 dark:text-teal-400">
              <Target size={18} />
            </div>
            <div>
              <h3 className="font-bold text-sm md:text-base text-slate-900 dark:text-white">
                {name}
              </h3>
              {targetDate && (
                <div className="flex items-center gap-1 text-xs text-slate-400 mt-0.5">
                  <Calendar size={12} />
                  <span>Target: {targetDate}</span>
                </div>
              )}
            </div>
          </div>

          {priority && (
            <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${getPriorityBadge()}`}>
              {priority}
            </span>
          )}
        </div>

        {/* Progress Bar */}
        <div className="mt-4 space-y-1.5">
          <div className="flex justify-between text-xs font-mono">
            <span className="font-bold text-teal-600 dark:text-teal-400">{progress}% Funded</span>
            <span className="text-slate-500">Remaining: {formatINR(remaining)}</span>
          </div>
          <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
            <div
              className="h-full rounded-full bg-teal-500 transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      </div>

      <div className="pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs">
        <div>
          <span className="text-slate-400 block text-[11px]">Saved / Target</span>
          <span className="font-mono font-bold text-slate-700 dark:text-slate-200">
            {formatINR(currentAmount)} / {formatINR(targetAmount)}
          </span>
        </div>

        {monthlyContribution ? (
          <div className="text-right">
            <span className="text-slate-400 block text-[11px]">Monthly SIP</span>
            <span className="font-mono font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-0.5 justify-end">
              <TrendingUp size={12} />
              {formatINR(monthlyContribution)}
            </span>
          </div>
        ) : null}
      </div>
    </div>
  );
}
