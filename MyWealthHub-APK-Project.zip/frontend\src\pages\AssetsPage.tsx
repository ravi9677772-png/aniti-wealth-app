import React, { useState, useEffect } from 'react';
import {
  Landmark,
  PlusCircle,
  TrendingUp,
  ShieldAlert,
  Building,
  Coins,
  LineChart,
  Home,
  CreditCard,
  Trash2,
} from 'lucide-react';
import { assetApi, liabilityApi } from '../services/api';
import { Asset, Liability } from '../types';
import { Modal } from '../components/common/Modal';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { formatINR } from '../hooks/useCurrency';

export function AssetsPage() {
  const [tab, setTab] = useState<'assets' | 'liabilities'>('assets');
  const [assets, setAssets] = useState<Asset[]>([]);
  const [liabilities, setLiabilities] = useState<Liability[]>([]);
  const [loading, setLoading] = useState(true);

  // Modal State
  const [isAssetModalOpen, setIsAssetModalOpen] = useState(false);
  const [isLiabModalOpen, setIsLiabModalOpen] = useState(false);

  // Asset Form
  const [assetName, setAssetName] = useState('');
  const [assetType, setAssetType] = useState('mutual_fund');
  const [institution, setInstitution] = useState('');
  const [purchaseValue, setPurchaseValue] = useState('');
  const [currentValue, setCurrentValue] = useState('');
  const [isEstimated, setIsEstimated] = useState(false);

  // Liability Form
  const [liabName, setLiabName] = useState('');
  const [liabType, setLiabType] = useState('home_loan');
  const [liabInstitution, setLiabInstitution] = useState('');
  const [principalAmount, setPrincipalAmount] = useState('');
  const [outstandingAmount, setOutstandingAmount] = useState('');
  const [interestRate, setInterestRate] = useState('');
  const [emiAmount, setEmiAmount] = useState('');
  const [nextEmiDate, setNextEmiDate] = useState('');

  const loadData = async () => {
    try {
      setLoading(true);
      const [aRes, lRes] = await Promise.all([
        assetApi.getAssets(),
        liabilityApi.getLiabilities(),
      ]);
      setAssets(aRes || []);
      setLiabilities(lRes || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleCreateAsset = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await assetApi.createAsset({
        name: assetName,
        type: assetType as any,
        institution,
        purchaseValue: parseFloat(purchaseValue || '0'),
        currentValue: parseFloat(currentValue || '0'),
        isEstimated: isEstimated ? 1 : 0,
      });
      setIsAssetModalOpen(false);
      setAssetName('');
      setPurchaseValue('');
      setCurrentValue('');
      loadData();
    } catch (err) {
      alert('Failed to save asset.');
    }
  };

  const handleCreateLiability = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await liabilityApi.createLiability({
        name: liabName,
        type: liabType as any,
        institution: liabInstitution,
        principalAmount: parseFloat(principalAmount || '0'),
        outstandingAmount: parseFloat(outstandingAmount || '0'),
        interestRate: interestRate ? parseFloat(interestRate) : undefined,
        emiAmount: emiAmount ? parseFloat(emiAmount) : undefined,
        nextEmiDate: nextEmiDate || undefined,
      });
      setIsLiabModalOpen(false);
      setLiabName('');
      setPrincipalAmount('');
      setOutstandingAmount('');
      setEmiAmount('');
      loadData();
    } catch (err) {
      alert('Failed to save liability.');
    }
  };

  const handleDeleteAsset = async (id: number) => {
    if (!window.confirm('Delete this asset entry?')) return;
    await assetApi.deleteAsset(id);
    loadData();
  };

  const handleDeleteLiability = async (id: number) => {
    if (!window.confirm('Delete this liability record?')) return;
    await liabilityApi.deleteLiability(id);
    loadData();
  };

  const totalAssetsPaise = assets.reduce((acc, a) => acc + (a.current_value || 0), 0);
  const totalLiabilitiesPaise = liabilities.reduce((acc, l) => acc + (l.outstanding_amount || 0), 0);
  const totalEmiPaise = liabilities.reduce((acc, l) => acc + (l.emi_amount || 0), 0);
  const netWorthPaise = totalAssetsPaise - totalLiabilitiesPaise;

  return (
    <div className="space-y-6">
      {/* Net Worth Summary Banner */}
      <div className="p-6 rounded-3xl bg-slate-900 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6 border border-slate-800">
        <div className="space-y-1">
          <div className="text-xs text-teal-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
            <TrendingUp size={16} />
            <span>Balance Sheet Intelligence</span>
          </div>
          <div className="text-3xl md:text-4xl font-black font-mono tracking-tight text-teal-300">
            {formatINR(netWorthPaise)}
          </div>
          <div className="text-xs text-slate-400">Total Net Worth (Excluding liquid cash in banks)</div>
        </div>

        <div className="flex gap-4 border-t md:border-t-0 md:border-l border-slate-800 pt-4 md:pt-0 md:pl-6 text-xs font-mono">
          <div>
            <span className="text-slate-400 block text-[11px]">Total Assets</span>
            <span className="text-emerald-400 font-bold text-sm">{formatINR(totalAssetsPaise)}</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[11px]">Total Debt</span>
            <span className="text-rose-400 font-bold text-sm">{formatINR(totalLiabilitiesPaise)}</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[11px]">Monthly EMIs</span>
            <span className="text-amber-400 font-bold text-sm">{formatINR(totalEmiPaise)}</span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center justify-between">
        <div className="flex gap-2 p-1 rounded-2xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-600 dark:text-slate-400">
          <button
            onClick={() => setTab('assets')}
            className={`px-5 py-2.5 rounded-xl transition ${
              tab === 'assets' ? 'bg-teal-500 text-white shadow-sm' : 'hover:text-white'
            }`}
          >
            Assets ({assets.length})
          </button>
          <button
            onClick={() => setTab('liabilities')}
            className={`px-5 py-2.5 rounded-xl transition ${
              tab === 'liabilities' ? 'bg-rose-500 text-white shadow-sm' : 'hover:text-white'
            }`}
          >
            Liabilities & Debt ({liabilities.length})
          </button>
        </div>

        <button
          onClick={() => (tab === 'assets' ? setIsAssetModalOpen(true) : setIsLiabModalOpen(true))}
          className="px-4 py-2.5 rounded-xl bg-teal-500 hover:bg-teal-600 text-white font-bold text-xs md:text-sm flex items-center gap-1.5 shadow-md shadow-teal-500/20 transition"
        >
          <PlusCircle size={16} />
          <span>{tab === 'assets' ? 'Add Asset' : 'Add Debt / Loan'}</span>
        </button>
      </div>

      {/* Content */}
      {loading ? (
        <LoadingSpinner message="Evaluating assets and liabilities..." />
      ) : tab === 'assets' ? (
        /* Assets List */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {assets.map((a) => (
            <div
              key={a.id}
              className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between space-y-4 hover:shadow-md transition"
            >
              <div>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2.5 rounded-xl bg-teal-50 dark:bg-teal-950/40 text-teal-600 dark:text-teal-400">
                      <Coins size={18} />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm text-slate-900 dark:text-white">{a.name}</h4>
                      <p className="text-xs text-slate-400">{a.institution || a.type.replace('_', ' ')}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => handleDeleteAsset(a.id)}
                    className="text-slate-400 hover:text-rose-500 transition p-1"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>

                <div className="mt-4">
                  <div className="text-xl font-bold font-mono text-slate-900 dark:text-white">
                    {formatINR(a.current_value)}
                  </div>
                  {a.is_estimated === 1 && (
                    <span className="text-[10px] uppercase font-semibold tracking-wider text-amber-500">
                      • Manually Estimated
                    </span>
                  )}
                </div>
              </div>

              {a.purchase_value > 0 && (
                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-500 font-mono flex justify-between">
                  <span>Invested: {formatINR(a.purchase_value)}</span>
                  <span className={a.current_value >= a.purchase_value ? 'text-emerald-500 font-bold' : 'text-rose-500 font-bold'}>
                    {a.current_value >= a.purchase_value ? '+' : ''}
                    {formatINR(a.current_value - a.purchase_value)}
                  </span>
                </div>
              )}
            </div>
          ))}
        </div>
      ) : (
        /* Liabilities List */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {liabilities.map((l) => (
            <div
              key={l.id}
              className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between space-y-4 hover:shadow-md transition"
            >
              <div>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400">
                      <CreditCard size={18} />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm text-slate-900 dark:text-white">{l.name}</h4>
                      <p className="text-xs text-slate-400">{l.institution || l.type.replace('_', ' ')}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => handleDeleteLiability(l.id)}
                    className="text-slate-400 hover:text-rose-500 transition p-1"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>

                <div className="mt-4">
                  <div className="text-xs text-slate-400">Outstanding Balance</div>
                  <div className="text-xl font-bold font-mono text-rose-600 dark:text-rose-400">
                    {formatINR(l.outstanding_amount)}
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 text-xs font-mono grid grid-cols-2 gap-2 text-slate-500">
                {l.emi_amount ? (
                  <div>
                    <span className="block text-[10px] text-slate-400">Monthly EMI</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">{formatINR(l.emi_amount)}</span>
                  </div>
                ) : null}
                {l.interest_rate ? (
                  <div>
                    <span className="block text-[10px] text-slate-400">Interest Rate</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">{l.interest_rate}% p.a.</span>
                  </div>
                ) : null}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Asset Modal */}
      <Modal isOpen={isAssetModalOpen} onClose={() => setIsAssetModalOpen(false)} title="Record Asset">
        <form onSubmit={handleCreateAsset} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Asset Name</label>
            <input
              type="text"
              required
              value={assetName}
              onChange={(e) => setAssetName(e.target.value)}
              placeholder="e.g. Parag Parikh Flexi Cap Fund"
              className="input-field text-sm rounded-xl"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Asset Type</label>
            <select
              value={assetType}
              onChange={(e) => setAssetType(e.target.value)}
              className="select-field text-sm rounded-xl"
            >
              <option value="mutual_fund">Mutual Fund / SIP</option>
              <option value="stocks">Stocks / Demat</option>
              <option value="fd">Fixed Deposit (FD)</option>
              <option value="rd">Recurring Deposit (RD)</option>
              <option value="gold">Gold / SGB</option>
              <option value="ppf">PPF / EPF / NPS</option>
              <option value="property">Real Estate / Property</option>
              <option value="other">Other Asset</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Current Value (₹)</label>
              <input
                type="number"
                step="any"
                required
                value={currentValue}
                onChange={(e) => setCurrentValue(e.target.value)}
                placeholder="e.g. 250000"
                className="input-field text-sm rounded-xl"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Invested Value (₹)</label>
              <input
                type="number"
                step="any"
                value={purchaseValue}
                onChange={(e) => setPurchaseValue(e.target.value)}
                placeholder="e.g. 200000"
                className="input-field text-sm rounded-xl"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Institution / Platform</label>
            <input
              type="text"
              value={institution}
              onChange={(e) => setInstitution(e.target.value)}
              placeholder="e.g. Zerodha, Groww, SBI"
              className="input-field text-sm rounded-xl"
            />
          </div>

          <div className="flex items-center gap-2 pt-2">
            <input
              type="checkbox"
              id="isEstimated"
              checked={isEstimated}
              onChange={(e) => setIsEstimated(e.target.checked)}
              className="w-4 h-4 rounded text-teal-500"
            />
            <label htmlFor="isEstimated" className="text-xs text-slate-600 dark:text-slate-400">
              This is a manual estimate (e.g. property, gold jewelry)
            </label>
          </div>

          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-teal-500 hover:bg-teal-600 text-white font-bold text-sm transition shadow-md"
          >
            Save Asset
          </button>
        </form>
      </Modal>

      {/* Liability Modal */}
      <Modal isOpen={isLiabModalOpen} onClose={() => setIsLiabModalOpen(false)} title="Record Loan / Liability">
        <form onSubmit={handleCreateLiability} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Loan / Liability Name</label>
            <input
              type="text"
              required
              value={liabName}
              onChange={(e) => setLiabName(e.target.value)}
              placeholder="e.g. HDFC Home Loan"
              className="input-field text-sm rounded-xl"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Type</label>
            <select
              value={liabType}
              onChange={(e) => setLiabType(e.target.value)}
              className="select-field text-sm rounded-xl"
            >
              <option value="home_loan">Home Loan</option>
              <option value="vehicle_loan">Vehicle / Car Loan</option>
              <option value="personal_loan">Personal Loan</option>
              <option value="education_loan">Education Loan</option>
              <option value="credit_card">Credit Card Outstanding</option>
              <option value="other">Other Borrowing</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Outstanding Principal (₹)</label>
              <input
                type="number"
                step="any"
                required
                value={outstandingAmount}
                onChange={(e) => setOutstandingAmount(e.target.value)}
                placeholder="e.g. 2500000"
                className="input-field text-sm rounded-xl"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Monthly EMI (₹)</label>
              <input
                type="number"
                step="any"
                value={emiAmount}
                onChange={(e) => setEmiAmount(e.target.value)}
                placeholder="e.g. 24500"
                className="input-field text-sm rounded-xl"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Interest Rate (%)</label>
              <input
                type="number"
                step="any"
                value={interestRate}
                onChange={(e) => setInterestRate(e.target.value)}
                placeholder="e.g. 8.65"
                className="input-field text-sm rounded-xl"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Lender Institution</label>
              <input
                type="text"
                value={liabInstitution}
                onChange={(e) => setLiabInstitution(e.target.value)}
                placeholder="e.g. HDFC Bank, SBI"
                className="input-field text-sm rounded-xl"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-rose-500 hover:bg-rose-600 text-white font-bold text-sm transition shadow-md"
          >
            Save Liability
          </button>
        </form>
      </Modal>
    </div>
  );
}
