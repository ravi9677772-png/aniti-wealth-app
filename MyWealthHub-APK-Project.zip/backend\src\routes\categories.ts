// ============================================================================
// My Wealth Hub — Categories Routes
// ============================================================================

import { Router, Response } from 'express';
import { getDb } from '../database';
import { AuthenticatedRequest } from '../types';
import { suggestCategory } from '../services/categoryRules';

const router = Router();

// Get categories
router.get('/', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const { type } = req.query;
  const db = getDb();

  let query = 'SELECT * FROM categories WHERE user_id = ? AND is_active = 1';
  const params: any[] = [userId];

  if (type) {
    query += ' AND type = ?';
    params.push(type);
  }

  query += ' ORDER BY type ASC, sort_order ASC, name ASC';
  const categories = db.prepare(query).all(...params);

  res.json({ success: true, data: categories });
});

// Categories with spending for current month
router.get('/with-spending', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const month = (req.query.month as string) || new Date().toISOString().slice(0, 7);
  const db = getDb();

  const categories = db
    .prepare(
      `SELECT c.*, COALESCE(SUM(t.amount), 0) as total_spent, COUNT(t.id) as transaction_count
       FROM categories c
       LEFT JOIN transactions t ON c.id = t.category_id AND strftime('%Y-%m', t.date) = ? AND t.type = 'expense'
       WHERE c.user_id = ? AND c.is_active = 1 AND c.type = 'expense'
       GROUP BY c.id
       ORDER BY total_spent DESC`
    )
    .all(month, userId);

  res.json({ success: true, data: categories });
});

// Suggest category for a merchant/description
router.post('/suggest', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const { description } = req.body;

  if (!description) {
    res.status(400).json({ success: false, error: 'Description is required' });
    return;
  }

  const suggestion = suggestCategory(userId, description);
  res.json({ success: true, data: suggestion });
});

// Create category
router.post('/', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const { name, type, parentId, icon, color } = req.body;

  if (!name || !type) {
    res.status(400).json({ success: false, error: 'Name and type are required' });
    return;
  }

  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO categories (user_id, name, type, parent_id, icon, color, is_default, sort_order)
    VALUES (?, ?, ?, ?, ?, ?, 0, 99)
  `);

  const result = stmt.run(userId, name, type, parentId || null, icon || '📁', color || '#14b8a6');
  const created = db.prepare('SELECT * FROM categories WHERE id = ?').get(result.lastInsertRowid);
  res.status(201).json({ success: true, data: created });
});

// Update category
router.put('/:id', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const { name, icon, color, isActive } = req.body;
  const db = getDb();

  const existing = db
    .prepare('SELECT * FROM categories WHERE id = ? AND user_id = ?')
    .get(req.params.id, userId) as any;

  if (!existing) {
    res.status(404).json({ success: false, error: 'Category not found' });
    return;
  }

  db.prepare(`
    UPDATE categories
    SET name = ?, icon = ?, color = ?, is_active = ?, updated_at = CURRENT_TIMESTAMP
    WHERE id = ? AND user_id = ?
  `).run(
    name ?? existing.name,
    icon ?? existing.icon,
    color ?? existing.color,
    isActive !== undefined ? (isActive ? 1 : 0) : existing.is_active,
    req.params.id,
    userId
  );

  const updated = db.prepare('SELECT * FROM categories WHERE id = ?').get(req.params.id);
  res.json({ success: true, data: updated });
});

// Delete category
router.delete('/:id', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const db = getDb();

  // If category has transactions, don't cascade delete; nullify or deactivate
  db.prepare('UPDATE categories SET is_active = 0 WHERE id = ? AND user_id = ?').run(req.params.id, userId);
  res.json({ success: true, message: 'Category deactivated.' });
});

export default router;
