// ============================================================================
// My Wealth Hub — Transactions Routes (CRUD, Search, Filter, NL Parsing, Balances)
// ============================================================================

import { Router, Response } from 'express';
import { getDb } from '../database';
import { AuthenticatedRequest, rupeesToPaise } from '../types';
import { parseNaturalLanguage } from '../services/nlpParser';
import { suggestCategory } from '../services/categoryRules';

const router = Router();

// Helper to adjust account balance safely inside a transaction
function adjustAccountBalance(db: any, accountId: number, deltaPaise: number) {
  db.prepare('UPDATE accounts SET balance = balance + ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
    .run(deltaPaise, accountId);
}

// ─── GET /api/transactions (Search & Filter) ─────────────────────────────────
router.get('/', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const db = getDb();

  const {
    startDate,
    endDate,
    type,
    categoryId,
    accountId,
    minAmount,
    maxAmount,
    search,
    sortBy = 'date',
    sortOrder = 'DESC',
    page = '1',
    limit = '50',
  } = req.query as Record<string, string>;

  let whereClauses: string[] = ['t.user_id = ?'];
  let params: any[] = [userId];

  if (startDate) {
    whereClauses.push('date(t.date) >= date(?)');
    params.push(startDate);
  }
  if (endDate) {
    whereClauses.push('date(t.date) <= date(?)');
    params.push(endDate);
  }
  if (type) {
    whereClauses.push('t.type = ?');
    params.push(type);
  }
  if (categoryId) {
    whereClauses.push('t.category_id = ?');
    params.push(categoryId);
  }
  if (accountId) {
    whereClauses.push('t.account_id = ?');
    params.push(accountId);
  }
  if (minAmount) {
    whereClauses.push('t.amount >= ?');
    params.push(rupeesToPaise(Number(minAmount)));
  }
  if (maxAmount) {
    whereClauses.push('t.amount <= ?');
    params.push(rupeesToPaise(Number(maxAmount)));
  }
  if (search) {
    whereClauses.push('(t.description LIKE ? OR t.merchant LIKE ? OR t.notes LIKE ?)');
    const term = `%${search}%`;
    params.push(term, term, term);
  }

  const whereSql = whereClauses.join(' AND ');

  // Count total for pagination
  const countRow = db.prepare(`SELECT COUNT(*) as count FROM transactions t WHERE ${whereSql}`).get(...params) as { count: number };
  const total = countRow.count;

  // Ordering
  const allowedSortCols: Record<string, string> = {
    date: 't.date',
    amount: 't.amount',
    type: 't.type',
    id: 't.id',
  };
  const orderCol = allowedSortCols[sortBy] || 't.date';
  const orderDir = sortOrder.toUpperCase() === 'ASC' ? 'ASC' : 'DESC';

  const pageNum = Math.max(1, parseInt(page, 10));
  const limitNum = Math.min(100, Math.max(1, parseInt(limit, 10)));
  const offset = (pageNum - 1) * limitNum;

  const transactions = db
    .prepare(
      `SELECT 
         t.*, 
         c.name as category_name, 
         c.icon as category_icon, 
         c.color as category_color,
         a.name as account_name,
         a.bank_name as account_bank,
         t_acc.name as transfer_to_account_name
       FROM transactions t
       LEFT JOIN categories c ON t.category_id = c.id
       LEFT JOIN accounts a ON t.account_id = a.id
       LEFT JOIN accounts t_acc ON t.transfer_to_account_id = t_acc.id
       WHERE ${whereSql}
       ORDER BY ${orderCol} ${orderDir}, t.id DESC
       LIMIT ? OFFSET ?`
    )
    .all(...params, limitNum, offset);

  res.json({
    success: true,
    data: transactions,
    pagination: {
      total,
      page: pageNum,
      limit: limitNum,
      totalPages: Math.ceil(total / limitNum),
    },
  });
});

// ─── GET /api/transactions/:id ───────────────────────────────────────────────
router.get('/:id', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const db = getDb();

  const transaction = db
    .prepare(
      `SELECT t.*, c.name as category_name, c.icon as category_icon, a.name as account_name
       FROM transactions t
       LEFT JOIN categories c ON t.category_id = c.id
       LEFT JOIN accounts a ON t.account_id = a.id
       WHERE t.id = ? AND t.user_id = ?`
    )
    .get(req.params.id, userId);

  if (!transaction) {
    res.status(404).json({ success: false, error: 'Transaction not found' });
    return;
  }
  res.json({ success: true, data: transaction });
});

// ─── POST /api/transactions (Create Transaction) ─────────────────────────────
router.post('/', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const db = getDb();

  const {
    accountId,
    categoryId,
    type,
    amount, // In rupees from UI
    date,
    description,
    merchant,
    paymentMode = 'other',
    referenceNumber,
    notes,
    isRecurring = 0,
    recurringFrequency,
    transferToAccountId,
    refundForTransactionId,
  } = req.body;

  if (!accountId || !type || amount === undefined || !date) {
    res.status(400).json({ success: false, error: 'Account, type, amount, and date are required' });
    return;
  }

  const amountPaise = rupeesToPaise(Number(amount));
  if (amountPaise <= 0) {
    res.status(400).json({ success: false, error: 'Amount must be greater than zero' });
    return;
  }

  if (type === 'transfer' && !transferToAccountId) {
    res.status(400).json({ success: false, error: 'Destination account is required for transfers' });
    return;
  }

  // Auto suggest category if not provided
  let resolvedCategoryId = categoryId;
  if (!resolvedCategoryId && (description || merchant) && type === 'expense') {
    const suggestion = suggestCategory(userId, description || merchant);
    if (suggestion) resolvedCategoryId = suggestion.categoryId;
  }

  const createTx = db.transaction(() => {
    const insertStmt = db.prepare(`
      INSERT INTO transactions (
        user_id, account_id, category_id, type, amount, date, description,
        merchant, payment_mode, reference_number, notes, is_recurring,
        recurring_frequency, transfer_to_account_id, refund_for_transaction_id, source
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'manual')
    `);

    const result = insertStmt.run(
      userId,
      accountId,
      resolvedCategoryId || null,
      type,
      amountPaise,
      date,
      description || null,
      merchant || null,
      paymentMode,
      referenceNumber || null,
      notes || null,
      isRecurring ? 1 : 0,
      recurringFrequency || null,
      transferToAccountId || null,
      refundForTransactionId || null
    );

    const txId = result.lastInsertRowid;

    // Adjust Account Balances
    if (type === 'income') {
      adjustAccountBalance(db, accountId, amountPaise);
    } else if (type === 'expense') {
      adjustAccountBalance(db, accountId, -amountPaise);
    } else if (type === 'transfer') {
      // Deduct from source account, add to destination account
      adjustAccountBalance(db, accountId, -amountPaise);
      adjustAccountBalance(db, transferToAccountId, amountPaise);
    } else if (type === 'refund') {
      adjustAccountBalance(db, accountId, amountPaise);
    }

    return txId;
  });

  try {
    const txId = createTx();
    const created = db.prepare('SELECT * FROM transactions WHERE id = ?').get(txId);
    res.status(201).json({ success: true, data: created });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── PUT /api/transactions/:id (Update Transaction) ──────────────────────────
router.put('/:id', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const db = getDb();

  const existing = db
    .prepare('SELECT * FROM transactions WHERE id = ? AND user_id = ?')
    .get(req.params.id, userId) as any;

  if (!existing) {
    res.status(404).json({ success: false, error: 'Transaction not found' });
    return;
  }

  const {
    accountId = existing.account_id,
    categoryId = existing.category_id,
    type = existing.type,
    amount,
    date = existing.date,
    description = existing.description,
    merchant = existing.merchant,
    paymentMode = existing.payment_mode,
    referenceNumber = existing.reference_number,
    notes = existing.notes,
    isRecurring = existing.is_recurring,
    recurringFrequency = existing.recurring_frequency,
    transferToAccountId = existing.transfer_to_account_id,
  } = req.body;

  const newAmountPaise = amount !== undefined ? rupeesToPaise(Number(amount)) : existing.amount;

  const updateTx = db.transaction(() => {
    // 1. Reverse previous balance impact
    if (existing.type === 'income' || existing.type === 'refund') {
      adjustAccountBalance(db, existing.account_id, -existing.amount);
    } else if (existing.type === 'expense') {
      adjustAccountBalance(db, existing.account_id, existing.amount);
    } else if (existing.type === 'transfer') {
      adjustAccountBalance(db, existing.account_id, existing.amount);
      if (existing.transfer_to_account_id) {
        adjustAccountBalance(db, existing.transfer_to_account_id, -existing.amount);
      }
    }

    // 2. Apply new balance impact
    if (type === 'income' || type === 'refund') {
      adjustAccountBalance(db, accountId, newAmountPaise);
    } else if (type === 'expense') {
      adjustAccountBalance(db, accountId, -newAmountPaise);
    } else if (type === 'transfer') {
      adjustAccountBalance(db, accountId, -newAmountPaise);
      if (transferToAccountId) {
        adjustAccountBalance(db, transferToAccountId, newAmountPaise);
      }
    }

    // 3. Update transaction record
    db.prepare(`
      UPDATE transactions
      SET account_id = ?, category_id = ?, type = ?, amount = ?, date = ?,
          description = ?, merchant = ?, payment_mode = ?, reference_number = ?,
          notes = ?, is_recurring = ?, recurring_frequency = ?, transfer_to_account_id = ?,
          updated_at = CURRENT_TIMESTAMP
      WHERE id = ? AND user_id = ?
    `).run(
      accountId,
      categoryId || null,
      type,
      newAmountPaise,
      date,
      description,
      merchant,
      paymentMode,
      referenceNumber,
      notes,
      isRecurring ? 1 : 0,
      recurringFrequency || null,
      transferToAccountId || null,
      req.params.id,
      userId
    );
  });

  try {
    updateTx();
    const updated = db.prepare('SELECT * FROM transactions WHERE id = ?').get(req.params.id);
    res.json({ success: true, data: updated });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── DELETE /api/transactions/:id (Reverse Balance and Delete) ───────────────
router.delete('/:id', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const db = getDb();

  const existing = db
    .prepare('SELECT * FROM transactions WHERE id = ? AND user_id = ?')
    .get(req.params.id, userId) as any;

  if (!existing) {
    res.status(404).json({ success: false, error: 'Transaction not found' });
    return;
  }

  const deleteTx = db.transaction(() => {
    // Reverse balance
    if (existing.type === 'income' || existing.type === 'refund') {
      adjustAccountBalance(db, existing.account_id, -existing.amount);
    } else if (existing.type === 'expense') {
      adjustAccountBalance(db, existing.account_id, existing.amount);
    } else if (existing.type === 'transfer') {
      adjustAccountBalance(db, existing.account_id, existing.amount);
      if (existing.transfer_to_account_id) {
        adjustAccountBalance(db, existing.transfer_to_account_id, -existing.amount);
      }
    }

    db.prepare('DELETE FROM transactions WHERE id = ? AND user_id = ?').run(req.params.id, userId);
  });

  try {
    deleteTx();
    res.json({ success: true, message: 'Transaction deleted and balance adjusted.' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── POST /api/transactions/parse-natural-language ───────────────────────────
router.post('/parse-natural-language', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const { text } = req.body;

  if (!text) {
    res.status(400).json({ success: false, error: 'Text prompt is required' });
    return;
  }

  const parsed = parseNaturalLanguage(text);

  // If category wasn't confidently guessed, try category rules
  const db = getDb();
  let categoryId: number | null = null;
  let categoryName: string | null = null;

  if (parsed.description || parsed.merchant) {
    const suggestion = suggestCategory(userId, parsed.description || parsed.merchant || '');
    if (suggestion) {
      categoryId = suggestion.categoryId;
      categoryName = suggestion.categoryName;
    }
  }

  // Get user's default account
  const defaultAccount = db
    .prepare('SELECT id, name FROM accounts WHERE user_id = ? AND is_active = 1 LIMIT 1')
    .get(userId) as { id: number; name: string } | undefined;

  res.json({
    success: true,
    data: {
      ...parsed,
      categoryId,
      categoryName: categoryName || parsed.categoryGuess,
      accountId: defaultAccount?.id || null,
      accountName: defaultAccount?.name || null,
    },
  });
});

export default router;
