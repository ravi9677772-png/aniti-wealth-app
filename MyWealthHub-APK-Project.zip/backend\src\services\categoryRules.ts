// ============================================================================
// My Wealth Hub — Category Rules Auto-Categorization Service
// ============================================================================

import { getDb } from '../database';

interface RuleRow {
  category_id: number;
  keyword: string;
}

interface CategoryRow {
  id: number;
  name: string;
  type: string;
}

/**
 * Suggest a category ID based on transaction description.
 * Checks user-defined rules first, then default patterns.
 */
export function suggestCategory(
  userId: number,
  description: string
): { categoryId: number; categoryName: string; matchedKeyword: string } | null {
  const db = getDb();
  const lower = description.toLowerCase();

  // 1. Check user-defined category rules (user-specific rules first)
  const rules = db
    .prepare(
      `SELECT cr.keyword, cr.category_id
       FROM category_rules cr
       WHERE cr.user_id = ? AND cr.is_active = 1
       ORDER BY LENGTH(cr.keyword) DESC`
    )
    .all(userId) as RuleRow[];

  for (const rule of rules) {
    if (lower.includes(rule.keyword.toLowerCase())) {
      const cat = db
        .prepare('SELECT id, name, type FROM categories WHERE id = ? AND user_id = ?')
        .get(rule.category_id, userId) as CategoryRow | undefined;

      if (cat) {
        return {
          categoryId: cat.id,
          categoryName: cat.name,
          matchedKeyword: rule.keyword,
        };
      }
    }
  }

  return null;
}

/**
 * Suggest multiple possible categories ranked by relevance.
 */
export function suggestCategories(
  userId: number,
  description: string,
  limit: number = 3
): { categoryId: number; categoryName: string; matchedKeyword: string }[] {
  const db = getDb();
  const lower = description.toLowerCase();
  const results: { categoryId: number; categoryName: string; matchedKeyword: string }[] = [];

  const rules = db
    .prepare(
      `SELECT cr.keyword, cr.category_id, c.name as category_name
       FROM category_rules cr
       JOIN categories c ON c.id = cr.category_id
       WHERE cr.user_id = ? AND cr.is_active = 1 AND c.is_active = 1
       ORDER BY LENGTH(cr.keyword) DESC`
    )
    .all(userId) as (RuleRow & { category_name: string })[];

  const seenCategoryIds = new Set<number>();

  for (const rule of rules) {
    if (lower.includes(rule.keyword.toLowerCase()) && !seenCategoryIds.has(rule.category_id)) {
      seenCategoryIds.add(rule.category_id);
      results.push({
        categoryId: rule.category_id,
        categoryName: rule.category_name,
        matchedKeyword: rule.keyword,
      });
      if (results.length >= limit) break;
    }
  }

  return results;
}

/**
 * Get all category rules for a user.
 */
export function getCategoryRules(userId: number) {
  const db = getDb();
  return db
    .prepare(
      `SELECT cr.*, c.name as category_name
       FROM category_rules cr
       JOIN categories c ON c.id = cr.category_id
       WHERE cr.user_id = ?
       ORDER BY cr.keyword`
    )
    .all(userId);
}

/**
 * Add a new category rule.
 */
export function addCategoryRule(userId: number, keyword: string, categoryId: number) {
  const db = getDb();
  return db
    .prepare(
      'INSERT INTO category_rules (user_id, keyword, category_id) VALUES (?, ?, ?)'
    )
    .run(userId, keyword.toLowerCase(), categoryId);
}

/**
 * Delete a category rule.
 */
export function deleteCategoryRule(userId: number, ruleId: number) {
  const db = getDb();
  return db
    .prepare('DELETE FROM category_rules WHERE id = ? AND user_id = ?')
    .run(ruleId, userId);
}
