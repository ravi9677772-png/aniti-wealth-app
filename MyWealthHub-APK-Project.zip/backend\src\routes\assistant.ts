// ============================================================================
// My Wealth Hub — AI Assistant Route
// Factually queries user's SQLite financial records
// ============================================================================

import { Router, Response } from 'express';
import { AuthenticatedRequest } from '../types';
import { processAssistantQuery } from '../services/assistantService';

const router = Router();

router.post('/query', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const { query } = req.body;

  if (!query || typeof query !== 'string') {
    res.status(400).json({ success: false, error: 'Query string is required' });
    return;
  }

  try {
    const response = processAssistantQuery(userId, query);
    res.json({ success: true, data: response });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

export default router;
