const getApiBaseUrl = (): string => {
  if (import.meta.env.VITE_API_BASE_URL) {
    return import.meta.env.VITE_API_BASE_URL;
  }
  if (typeof window !== 'undefined' && window.location && window.location.origin) {
    const origin = window.location.origin;
    // If running in browser or PWA on mobile via LAN IP (e.g. http://192.168.x.x:3001)
    if (origin.startsWith('http://') || origin.startsWith('https://')) {
      if (!origin.includes('localhost') && !origin.includes('127.0.0.1')) {
        return `${origin}/api`;
      }
    }
  }
  return 'http://localhost:3001/api';
};

export const API_BASE_URL = getApiBaseUrl();

export const APP_NAME = 'My Wealth Hub';

export const CURRENCY = {
  code: 'INR',
  symbol: '₹',
  locale: 'en-IN',
};

export const DATE_FORMAT = 'dd MMM yyyy';
export const DATE_TIME_FORMAT = 'dd MMM yyyy, hh:mm a';
export const MONTH_FORMAT = 'MMM yyyy';

export const TRANSACTION_TYPES = ['income', 'expense', 'transfer', 'refund'] as const;

export const PAYMENT_MODES = [
  { value: 'upi', label: 'UPI' },
  { value: 'cash', label: 'Cash' },
  { value: 'credit_card', label: 'Credit Card' },
  { value: 'debit_card', label: 'Debit Card' },
  { value: 'imps', label: 'IMPS' },
  { value: 'neft', label: 'NEFT' },
  { value: 'rtgs', label: 'RTGS' },
  { value: 'cheque', label: 'Cheque' },
  { value: 'other', label: 'Other' },
] as const;

export const ACCOUNT_TYPES = [
  { value: 'savings', label: 'Savings Account' },
  { value: 'current', label: 'Current Account' },
  { value: 'credit_card', label: 'Credit Card' },
  { value: 'cash', label: 'Cash' },
  { value: 'wallet', label: 'Digital Wallet' },
  { value: 'fd', label: 'Fixed Deposit' },
  { value: 'rd', label: 'Recurring Deposit' },
  { value: 'investment', label: 'Investment' },
] as const;

export const ASSET_TYPES = [
  { value: 'bank_account', label: 'Bank Account' },
  { value: 'fixed_deposit', label: 'Fixed Deposit' },
  { value: 'mutual_fund', label: 'Mutual Fund' },
  { value: 'stocks', label: 'Stocks' },
  { value: 'epf', label: 'EPF/PPF' },
  { value: 'nps', label: 'NPS' },
  { value: 'real_estate', label: 'Real Estate' },
  { value: 'gold', label: 'Gold' },
  { value: 'vehicle', label: 'Vehicle' },
  { value: 'other', label: 'Other' },
] as const;

export const LIABILITY_TYPES = [
  { value: 'home_loan', label: 'Home Loan' },
  { value: 'car_loan', label: 'Car Loan' },
  { value: 'personal_loan', label: 'Personal Loan' },
  { value: 'education_loan', label: 'Education Loan' },
  { value: 'credit_card', label: 'Credit Card Due' },
  { value: 'other', label: 'Other' },
] as const;

export const GOAL_TYPES = [
  { value: 'emergency_fund', label: 'Emergency Fund', icon: '🛡️' },
  { value: 'retirement', label: 'Retirement', icon: '🏖️' },
  { value: 'home', label: 'Home Purchase', icon: '🏠' },
  { value: 'vehicle', label: 'Vehicle', icon: '🚗' },
  { value: 'education', label: 'Education', icon: '🎓' },
  { value: 'vacation', label: 'Vacation', icon: '✈️' },
  { value: 'wedding', label: 'Wedding', icon: '💒' },
  { value: 'gadget', label: 'Gadget', icon: '📱' },
  { value: 'investment', label: 'Investment', icon: '📈' },
  { value: 'other', label: 'Other', icon: '🎯' },
] as const;

export const EXPENSE_CATEGORIES = [
  { value: 'food', label: 'Food & Dining', icon: '🍕', color: '#ef4444' },
  { value: 'groceries', label: 'Groceries', icon: '🛒', color: '#f97316' },
  { value: 'transport', label: 'Transport', icon: '🚌', color: '#eab308' },
  { value: 'fuel', label: 'Fuel', icon: '⛽', color: '#84cc16' },
  { value: 'shopping', label: 'Shopping', icon: '🛍️', color: '#22c55e' },
  { value: 'entertainment', label: 'Entertainment', icon: '🎬', color: '#14b8a6' },
  { value: 'health', label: 'Healthcare', icon: '🏥', color: '#06b6d4' },
  { value: 'education', label: 'Education', icon: '📚', color: '#3b82f6' },
  { value: 'utilities', label: 'Utilities', icon: '💡', color: '#6366f1' },
  { value: 'rent', label: 'Rent', icon: '🏠', color: '#8b5cf6' },
  { value: 'emi', label: 'EMI', icon: '🏦', color: '#a855f7' },
  { value: 'insurance', label: 'Insurance', icon: '🔒', color: '#d946ef' },
  { value: 'subscriptions', label: 'Subscriptions', icon: '📺', color: '#ec4899' },
  { value: 'personal', label: 'Personal Care', icon: '💇', color: '#f43f5e' },
  { value: 'gifts', label: 'Gifts & Donations', icon: '🎁', color: '#fb923c' },
  { value: 'travel', label: 'Travel', icon: '✈️', color: '#38bdf8' },
  { value: 'investment', label: 'Investment', icon: '📈', color: '#4ade80' },
  { value: 'other', label: 'Other', icon: '📌', color: '#94a3b8' },
] as const;

export const INCOME_CATEGORIES = [
  { value: 'salary', label: 'Salary', icon: '💰', color: '#22c55e' },
  { value: 'freelance', label: 'Freelance', icon: '💻', color: '#14b8a6' },
  { value: 'business', label: 'Business', icon: '🏢', color: '#3b82f6' },
  { value: 'interest', label: 'Interest', icon: '🏦', color: '#6366f1' },
  { value: 'dividend', label: 'Dividend', icon: '📊', color: '#8b5cf6' },
  { value: 'rental', label: 'Rental Income', icon: '🏠', color: '#a855f7' },
  { value: 'refund', label: 'Refund', icon: '↩️', color: '#06b6d4' },
  { value: 'cashback', label: 'Cashback', icon: '🎉', color: '#eab308' },
  { value: 'gift', label: 'Gift', icon: '🎁', color: '#ec4899' },
  { value: 'other', label: 'Other', icon: '📌', color: '#94a3b8' },
] as const;

export const CHART_COLORS = {
  income: '#22c55e',
  expense: '#ef4444',
  savings: '#14b8a6',
  netWorth: '#3b82f6',
  teal: '#14b8a6',
  navy: '#1e293b',
  categories: [
    '#ef4444', '#f97316', '#eab308', '#84cc16', '#22c55e',
    '#14b8a6', '#06b6d4', '#3b82f6', '#6366f1', '#8b5cf6',
    '#a855f7', '#d946ef', '#ec4899', '#f43f5e', '#fb923c',
    '#38bdf8', '#4ade80', '#94a3b8',
  ],
};

export const RECURRING_FREQUENCIES = [
  { value: 'daily', label: 'Daily' },
  { value: 'weekly', label: 'Weekly' },
  { value: 'monthly', label: 'Monthly' },
  { value: 'quarterly', label: 'Quarterly' },
  { value: 'half_yearly', label: 'Half Yearly' },
  { value: 'yearly', label: 'Yearly' },
] as const;
