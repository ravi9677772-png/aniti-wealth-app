import React from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { Sidebar } from './Sidebar';
import { BottomNav } from './BottomNav';
import { Header } from './Header';

const TITLE_MAP: Record<string, string> = {
  '/': 'Cockpit & Dashboard',
  '/transactions': 'Transactions Register',
  '/add-transaction': 'Add Transaction',
  '/budgets': 'Monthly Budgets',
  '/insurance': 'Insurance Desk & Renewal Calendar',
  '/investments': 'Mutual Funds & Demat Stocks',
  '/assets': 'Assets & Liabilities',
  '/goals': 'Financial Goals',
  '/assistant': 'AI Financial Assistant',
  '/reports': 'Financial Intelligence',
  '/import': 'Bank Statement Import',
  '/settings': 'Configuration & Settings',
};

export function Layout() {
  const location = useLocation();
  const title = TITLE_MAP[location.pathname] || 'My Wealth Hub';

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-50 dark:bg-slate-950 font-sans">
      {/* Desktop Sidebar */}
      <Sidebar />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        <Header title={title} />

        <main className="flex-1 overflow-y-auto px-4 py-4 md:px-8 md:py-6 pb-20 md:pb-8">
          <div className="max-w-7xl mx-auto">
            <Outlet />
          </div>
        </main>

        {/* Mobile Bottom Navigation */}
        <BottomNav />
      </div>
    </div>
  );
}
