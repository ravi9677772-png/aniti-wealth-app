/* ───────────────────── Auth ───────────────────── */
export interface User {
  id: string;
  email: string;
  displayName: string;
  createdAt: string;
}

export interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterCredentials {
  email: string;
  password: string;
  displayName: string;
}

export interface AuthResponse {
  user: User;
  token: string;
}

/* ───────────────────── Accounts ───────────────────── */
export interface Account {
  id: string;
  userId: string;
  name: string;
  type: string;
  balance: number; // in paise
  institution?: string;
  accountNumber?: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface AccountFormData {
  name: string;
  type: string;
  balance: number;
  institution?: string;
  accountNumber?: string;
}

/* ───────────────────── Transactions ───────────────────── */
export type TransactionType = 'income' | 'expense' | 'transfer' | 'refund';

export interface Transaction {
  id: string;
  userId: string;
  type: TransactionType;
  amount: number; // in paise
  date: string;
  accountId: string;
  accountName?: string;
  toAccountId?: string;
  toAccountName?: string;
  category: string;
  subcategory?: string;
  description: string;
  merchant?: string;
  paymentMode: string;
  notes?: string;
  isRecurring: boolean;
  recurringFrequency?: string;
  tags?: string[];
  createdAt: string;
  updatedAt: string;
}

export interface TransactionFormData {
  type: TransactionType;
  amount: number;
  date: string;
  accountId: string;
  toAccountId?: string;
  category: string;
  subcategory?: string;
  description: string;
  merchant?: string;
  paymentMode: string;
  notes?: string;
  isRecurring: boolean;
  recurringFrequency?: string;
  tags?: string[];
}

export interface TransactionFilters {
  search?: string;
  type?: TransactionType;
  category?: string;
  accountId?: string;
  startDate?: string;
  endDate?: string;
  minAmount?: number;
  maxAmount?: number;
  sortBy?: 'date' | 'amount' | 'category';
  sortOrder?: 'asc' | 'desc';
  page?: number;
  limit?: number;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

/* ───────────────────── Budgets ───────────────────── */
export interface Budget {
  id: string;
  userId: string;
  category: string;
  limit: number; // in paise
  spent: number; // in paise
  month: number; // 1-12
  year: number;
  createdAt: string;
  updatedAt: string;
}

export interface BudgetFormData {
  category: string;
  limit: number;
  month: number;
  year: number;
}

export interface BudgetSummary {
  totalBudgeted: number;
  totalSpent: number;
  budgets: Budget[];
}

/* ───────────────────── Assets & Liabilities ───────────────────── */
export interface Asset {
  id: string;
  userId: string;
  name: string;
  type: string;
  currentValue: number; // in paise
  purchaseValue?: number;
  purchaseDate?: string;
  institution?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface AssetFormData {
  name: string;
  type: string;
  currentValue: number;
  purchaseValue?: number;
  purchaseDate?: string;
  institution?: string;
  notes?: string;
}

export interface Liability {
  id: string;
  userId: string;
  name: string;
  type: string;
  principalAmount: number; // in paise
  outstandingAmount: number; // in paise
  interestRate: number; // percentage
  emiAmount?: number; // in paise
  startDate: string;
  endDate?: string;
  institution?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface LiabilityFormData {
  name: string;
  type: string;
  principalAmount: number;
  outstandingAmount: number;
  interestRate: number;
  emiAmount?: number;
  startDate: string;
  endDate?: string;
  institution?: string;
  notes?: string;
}

export interface NetWorthSummary {
  totalAssets: number;
  totalLiabilities: number;
  netWorth: number;
  assets: Asset[];
  liabilities: Liability[];
}

/* ───────────────────── Goals ───────────────────── */
export interface Goal {
  id: string;
  userId: string;
  name: string;
  type: string;
  targetAmount: number; // in paise
  currentAmount: number; // in paise
  targetDate: string;
  priority: 'high' | 'medium' | 'low';
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface GoalFormData {
  name: string;
  type: string;
  targetAmount: number;
  currentAmount: number;
  targetDate: string;
  priority: 'high' | 'medium' | 'low';
  notes?: string;
}

/* ───────────────────── Reports / Dashboard ───────────────────── */
export interface DashboardData {
  totalBalance: number;
  accounts: Account[];
  monthlyIncome: number;
  monthlyExpenses: number;
  monthlySavings: number;
  savingsRate: number;
  netWorth: number;
  totalAssets: number;
  totalLiabilities: number;
  recentTransactions: Transaction[];
  upcomingBills: Transaction[];
  upcomingInsurance?: any[];
  budgetSummary: BudgetSummary;
  incomeExpenseChart: MonthlyData[];
  categorySpending: CategoryData[];
}

export interface MonthlyData {
  month: string;
  income: number;
  expense: number;
  savings: number;
}

export interface CategoryData {
  category: string;
  amount: number;
  percentage: number;
  color: string;
  icon?: string;
}

export interface NetWorthHistory {
  date: string;
  assets: number;
  liabilities: number;
  netWorth: number;
}

export interface ReportData {
  incomeExpense: MonthlyData[];
  categorySpending: CategoryData[];
  savingsTrend: { month: string; savings: number; rate: number }[];
  netWorthHistory: NetWorthHistory[];
  topCategories: CategoryData[];
  monthlyComparison: {
    currentMonth: { income: number; expense: number; savings: number };
    previousMonth: { income: number; expense: number; savings: number };
  };
}

/* ───────────────────── AI Assistant ───────────────────── */
export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  data?: Record<string, unknown>;
}

/* ───────────────────── Import ───────────────────── */
export interface ImportMapping {
  dateColumn: string;
  descriptionColumn: string;
  amountColumn: string;
  debitColumn?: string;
  creditColumn?: string;
  categoryColumn?: string;
}

export interface ImportPreview {
  rows: Record<string, string>[];
  headers: string[];
  totalRows: number;
  duplicates: number[];
}

export interface ImportHistory {
  id: string;
  fileName: string;
  accountId: string;
  accountName: string;
  rowsImported: number;
  rowsSkipped: number;
  importedAt: string;
}

/* ───────────────────── Settings ───────────────────── */
export interface CategoryConfig {
  id: string;
  name: string;
  type: 'income' | 'expense';
  icon: string;
  color: string;
  subcategories?: string[];
}

export interface AppSettings {
  darkMode: boolean;
  currency: string;
  dateFormat: string;
  categories: CategoryConfig[];
}

/* ───────────────────── API ───────────────────── */
export interface ApiError {
  message: string;
  statusCode: number;
  errors?: Record<string, string[]>;
}
