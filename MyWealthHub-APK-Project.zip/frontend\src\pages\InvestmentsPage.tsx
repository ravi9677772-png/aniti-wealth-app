import React, { useState, useEffect } from 'react';
import {
  TrendingUp,
  FileSpreadsheet,
  UploadCloud,
  PlusCircle,
  Building2,
  PieChart,
  LineChart,
  Sparkles,
  CheckCircle2,
  ExternalLink,
  Trash2,
  RefreshCw,
  Coins,
} from 'lucide-react';
import { investmentsApi } from '../services/api';
import { Modal } from '../components/common/Modal';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { EmptyState } from '../components/common/EmptyState';
import { formatINR } from '../hooks/useCurrency';

export function InvestmentsPage() {
  const [activeTab, setActiveTab] = useState<'mutual_funds' | 'stocks' | 'brokers'>('mutual_funds');
  const [mutualFunds, setMutualFunds] = useState<any[]>([]);
  const [stocks, setStocks] = useState<any[]>([]);
  const [brokers, setBrokers] = useState<any[]>([]);
  const [summary, setSummary] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);

  // Modals
  const [isCasModalOpen, setIsCasModalOpen] = useState(false);
  const [isStockImportModalOpen, setIsStockImportModalOpen] = useState(false);
  const [isAddStockModalOpen, setIsAddStockModalOpen] = useState(false);
  const [isBrokerModalOpen, setIsBrokerModalOpen] = useState(false);

  // CAS Upload
  const [casFile, setCasFile] = useState<File | null>(null);
  const [casUploading, setCasUploading] = useState(false);

  // Broker File Upload
  const [brokerFile, setBrokerFile] = useState<File | null>(null);
  const [selectedBrokerName, setSelectedBrokerName] = useState('Zerodha Kite');
  const [brokerUploading, setBrokerUploading] = useState(false);

  // Manual Stock Form
  const [stockSymbol, setStockSymbol] = useState('');
  const [stockCompany, setStockCompany] = useState('');
  const [stockBroker, setStockBroker] = useState('Zerodha Kite');
  const [stockQty, setStockQty] = useState('');
  const [stockBuyPrice, setStockBuyPrice] = useState('');
  const [stockCurPrice, setStockCurPrice] = useState('');

  // Broker Connect Form
  const [connectBrokerName, setConnectBrokerName] = useState('Zerodha Kite Connect');
  const [connectApiKey, setConnectApiKey] = useState('');
  const [connectApiSecret, setConnectApiSecret] = useState('');

  const loadData = async () => {
    try {
      setLoading(true);
      const [mfRes, stockRes, brokerRes, sumRes] = await Promise.all([
        investmentsApi.getMutualFunds(),
        investmentsApi.getStocks(),
        investmentsApi.getBrokers(),
        investmentsApi.getSummary(),
      ]);
      setMutualFunds(mfRes || []);
      setStocks(stockRes || []);
      setBrokers(brokerRes || []);
      setSummary(sumRes || null);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleCasUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!casFile) return;
    setCasUploading(true);
    try {
      const res = await investmentsApi.importCasStatement(casFile);
      alert(res.message || 'CAS statement processed successfully!');
      setIsCasModalOpen(false);
      setCasFile(null);
      loadData();
    } catch (err: any) {
      alert(err?.response?.data?.error || 'Failed to process CAS file.');
    } finally {
      setCasUploading(false);
    }
  };

  const handleBrokerImport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!brokerFile) return;
    setBrokerUploading(true);
    try {
      const res = await investmentsApi.importBrokerHoldings(brokerFile, selectedBrokerName);
      alert(res.message || 'Broker holdings imported successfully!');
      setIsStockImportModalOpen(false);
      setBrokerFile(null);
      loadData();
    } catch (err: any) {
      alert(err?.response?.data?.error || 'Failed to import broker holdings.');
    } finally {
      setBrokerUploading(false);
    }
  };

  const handleAddStock = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await investmentsApi.addStock({
        symbol: stockSymbol,
        companyName: stockCompany,
        brokerName: stockBroker,
        quantity: parseInt(stockQty, 10),
        buyPrice: parseFloat(stockBuyPrice),
        currentPrice: stockCurPrice ? parseFloat(stockCurPrice) : undefined,
      });
      setIsAddStockModalOpen(false);
      setStockSymbol('');
      setStockQty('');
      setStockBuyPrice('');
      setStockCurPrice('');
      loadData();
    } catch (err) {
      alert('Failed to save stock.');
    }
  };

  const handleConnectBroker = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await investmentsApi.connectBroker(connectBrokerName, connectApiKey, connectApiSecret);
      alert(`${connectBrokerName} API credentials saved.`);
      setIsBrokerModalOpen(false);
      setConnectApiKey('');
      setConnectApiSecret('');
      loadData();
    } catch (err) {
      alert('Failed to save broker connection.');
    }
  };

  const handleDeleteMf = async (id: number) => {
    if (!window.confirm('Delete this mutual fund holding?')) return;
    await investmentsApi.deleteMutualFund(id);
    loadData();
  };

  const handleDeleteStock = async (id: number) => {
    if (!window.confirm('Delete this stock holding?')) return;
    await investmentsApi.deleteStock(id);
    loadData();
  };

  const comb = summary?.combined || { totalInvested: 0, totalCurrent: 0, totalGain: 0, returnPercentage: 0 };

  return (
    <div className="space-y-6">
      {/* Portfolio Grand Total Banner */}
      <div className="p-6 rounded-3xl bg-slate-900 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6 border border-slate-800">
        <div className="space-y-1">
          <div className="text-xs text-teal-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
            <TrendingUp size={16} />
            <span>Market Investments & Portfolio Tracker</span>
          </div>
          <div className="text-3xl md:text-4xl font-black font-mono tracking-tight text-teal-300">
            {formatINR(comb.totalCurrent)}
          </div>
          <div className="text-xs text-slate-400 font-mono">
            Invested Capital: {formatINR(comb.totalInvested)} • Overall Gain:{' '}
            <span className={comb.totalGain >= 0 ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
              {comb.totalGain >= 0 ? '+' : ''}{formatINR(comb.totalGain)} ({comb.returnPercentage}%)
            </span>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setIsCasModalOpen(true)}
            className="px-4 py-2.5 rounded-xl bg-teal-500 hover:bg-teal-600 text-white font-bold text-xs flex items-center gap-1.5 shadow-md transition"
          >
            <UploadCloud size={16} />
            <span>Import CAMS CAS</span>
          </button>
          <button
            onClick={() => setIsStockImportModalOpen(true)}
            className="px-4 py-2.5 rounded-xl bg-blue-500 hover:bg-blue-600 text-white font-bold text-xs flex items-center gap-1.5 shadow-md transition"
          >
            <FileSpreadsheet size={16} />
            <span>Import Broker CSV</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center justify-between">
        <div className="flex gap-2 p-1 rounded-2xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-600 dark:text-slate-400">
          <button
            onClick={() => setActiveTab('mutual_funds')}
            className={`px-5 py-2.5 rounded-xl transition ${
              activeTab === 'mutual_funds' ? 'bg-teal-500 text-white shadow-sm' : 'hover:text-white'
            }`}
          >
            Mutual Funds ({mutualFunds.length})
          </button>
          <button
            onClick={() => setActiveTab('stocks')}
            className={`px-5 py-2.5 rounded-xl transition ${
              activeTab === 'stocks' ? 'bg-blue-500 text-white shadow-sm' : 'hover:text-white'
            }`}
          >
            Demat Stocks ({stocks.length})
          </button>
          <button
            onClick={() => setActiveTab('brokers')}
            className={`px-5 py-2.5 rounded-xl transition ${
              activeTab === 'brokers' ? 'bg-indigo-500 text-white shadow-sm' : 'hover:text-white'
            }`}
          >
            Brokers & APIs ({brokers.length})
          </button>
        </div>

        {activeTab === 'stocks' && (
          <button
            onClick={() => setIsAddStockModalOpen(true)}
            className="px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 text-xs font-bold flex items-center gap-1.5"
          >
            <PlusCircle size={14} />
            <span>Add Single Stock</span>
          </button>
        )}

        {activeTab === 'brokers' && (
          <button
            onClick={() => setIsBrokerModalOpen(true)}
            className="px-3.5 py-2 rounded-xl bg-indigo-500 text-white font-bold text-xs flex items-center gap-1.5"
          >
            <PlusCircle size={14} />
            <span>Connect Broker API</span>
          </button>
        )}
      </div>

      {/* Content */}
      {loading ? (
        <LoadingSpinner message="Fetching live investment valuations..." />
      ) : activeTab === 'mutual_funds' ? (
        /* Mutual Funds Tab */
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-teal-500/10 border border-teal-500/20 text-xs text-teal-800 dark:text-teal-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles size={16} className="text-teal-500 shrink-0" />
              <span>
                <strong>CAMS & KFintech CAS Sync:</strong> You can download your official SEBI Consolidated Account Statement (CAS) from camsonline.com or mfcentral.com and upload it directly.
              </span>
            </div>
            <button
              onClick={() => setIsCasModalOpen(true)}
              className="text-xs font-bold underline shrink-0 ml-3"
            >
              Upload CAS Statement
            </button>
          </div>

          {mutualFunds.length === 0 ? (
            <EmptyState
              icon={Coins}
              title="No Mutual Fund Holdings"
              description="Upload your CAMS/KFintech CAS statement to populate all your mutual fund schemes, NAVs, and units in one go."
              actionText="Upload CAMS CAS"
              onAction={() => setIsCasModalOpen(true)}
            />
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {mutualFunds.map((mf) => {
                const gain = mf.current_value - mf.invested_amount;
                return (
                  <div
                    key={mf.id}
                    className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between space-y-4 hover:shadow-md transition"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h4 className="font-bold text-sm text-slate-900 dark:text-white leading-tight">
                            {mf.scheme_name}
                          </h4>
                          <p className="text-xs text-slate-400 mt-0.5">
                            {mf.amc || 'Mutual Fund'} {mf.folio_number ? `• Folio ${mf.folio_number}` : ''}
                          </p>
                        </div>
                        <button
                          onClick={() => handleDeleteMf(mf.id)}
                          className="text-slate-400 hover:text-rose-500 transition p-1"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>

                      <div className="mt-4">
                        <div className="text-xl font-bold font-mono text-slate-900 dark:text-white">
                          {formatINR(mf.current_value)}
                        </div>
                        <div className="text-xs font-mono text-slate-400 mt-0.5">
                          {mf.units} units @ NAV ₹{mf.nav}
                        </div>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-slate-100 dark:border-slate-800 text-xs font-mono flex items-center justify-between">
                      <span className="text-slate-400">Invested: {formatINR(mf.invested_amount)}</span>
                      <span className={gain >= 0 ? 'text-emerald-500 font-bold' : 'text-rose-500 font-bold'}>
                        {gain >= 0 ? '+' : ''}{formatINR(gain)}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : activeTab === 'stocks' ? (
        /* Stocks Tab */
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-blue-500/10 border border-blue-500/20 text-xs text-blue-800 dark:text-blue-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles size={16} className="text-blue-500 shrink-0" />
              <span>
                <strong>Indian Broker Integrations:</strong> Directly ingest holdings statements from <strong>Zerodha (Kite Holdings CSV)</strong>, <strong>Groww</strong>, <strong>Upstox</strong>, and <strong>Angel One</strong>.
              </span>
            </div>
            <button
              onClick={() => setIsStockImportModalOpen(true)}
              className="text-xs font-bold underline shrink-0 ml-3"
            >
              Import Holdings File
            </button>
          </div>

          {stocks.length === 0 ? (
            <EmptyState
              icon={LineChart}
              title="No Stock Holdings Recorded"
              description="Import your holdings CSV from Zerodha Kite, Groww, or Upstox to track P&L, allocation, and current value."
              actionText="Import Broker CSV"
              onAction={() => setIsStockImportModalOpen(true)}
            />
          ) : (
            <div className="overflow-x-auto bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm p-4">
              <table className="w-full text-xs text-left">
                <thead>
                  <tr className="border-b border-slate-100 dark:border-slate-800 font-mono text-slate-400">
                    <th className="p-3">Scrip / Symbol</th>
                    <th className="p-3">Broker</th>
                    <th className="p-3 text-right">Quantity</th>
                    <th className="p-3 text-right">Avg Cost</th>
                    <th className="p-3 text-right">LTP (CMP)</th>
                    <th className="p-3 text-right">Cur Value</th>
                    <th className="p-3 text-right">P&L</th>
                    <th className="p-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono">
                  {stocks.map((s) => (
                    <tr key={s.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="p-3 font-sans font-bold text-slate-900 dark:text-white">
                        {s.symbol}
                        <span className="block text-[11px] font-normal text-slate-400">{s.company_name}</span>
                      </td>
                      <td className="p-3 text-slate-500">{s.broker_name}</td>
                      <td className="p-3 text-right font-bold">{s.quantity}</td>
                      <td className="p-3 text-right">₹{(s.buy_price / 100).toFixed(2)}</td>
                      <td className="p-3 text-right">₹{(s.current_price / 100).toFixed(2)}</td>
                      <td className="p-3 text-right font-bold text-slate-900 dark:text-white">
                        {formatINR(s.current_value)}
                      </td>
                      <td className="p-3 text-right">
                        <span className={`font-bold ${s.pnl >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                          {s.pnl >= 0 ? '+' : ''}{formatINR(s.pnl)} ({s.pnl_percentage ? s.pnl_percentage.toFixed(1) : 0}%)
                        </span>
                      </td>
                      <td className="p-3 text-right">
                        <button
                          onClick={() => handleDeleteStock(s.id)}
                          className="text-slate-400 hover:text-rose-500 transition p-1"
                        >
                          <Trash2 size={15} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      ) : (
        /* Brokers & Connectors Tab */
        <div className="space-y-4">
          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 space-y-3">
            <h3 className="font-bold text-sm text-slate-800 dark:text-white flex items-center gap-2">
              <Building2 size={18} className="text-indigo-500" />
              <span>Configured Broker Connectors</span>
            </h3>
            <p className="text-xs text-slate-500">
              Direct connection options for Zerodha Kite Connect, Upstox Developer API, and Groww.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-slate-800 dark:text-white">Zerodha Kite Connect</span>
                  <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700">
                    Active
                  </span>
                </div>
                <p className="text-xs text-slate-400">API Key: kite_api_live_user_demo</p>
                <div className="text-[11px] text-slate-500 font-mono">Last holding sync: Today, Asia/Kolkata</div>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-slate-800 dark:text-white">Groww / Upstox</span>
                  <button
                    onClick={() => setIsBrokerModalOpen(true)}
                    className="text-xs text-indigo-500 font-bold hover:underline"
                  >
                    + Configure
                  </button>
                </div>
                <p className="text-xs text-slate-400">Statement file ingestion or Developer API token.</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CAMS CAS Upload Modal */}
      <Modal isOpen={isCasModalOpen} onClose={() => setIsCasModalOpen(false)} title="Import CAMS / KFintech CAS Statement">
        <form onSubmit={handleCasUpload} className="space-y-4">
          <p className="text-xs text-slate-600 dark:text-slate-300">
            Upload your Consolidated Account Statement (CAS) in Excel or CSV format from <strong>CAMS Online</strong> or <strong>MF Central</strong>.
          </p>

          <div className="border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-2xl p-6 text-center">
            <Coins className="w-10 h-10 text-teal-500 mx-auto mb-2" />
            <input
              type="file"
              accept=".xlsx, .xls, .csv"
              required
              onChange={(e) => setCasFile(e.target.files?.[0] || null)}
              className="text-xs text-slate-500"
            />
          </div>

          <button
            type="submit"
            disabled={casUploading || !casFile}
            className="w-full py-3 rounded-xl bg-teal-500 hover:bg-teal-600 text-white font-bold text-sm transition shadow-md disabled:opacity-50"
          >
            {casUploading ? 'Parsing Portfolio...' : 'Sync Mutual Fund Folios'}
          </button>
        </form>
      </Modal>

      {/* Broker CSV Import Modal */}
      <Modal isOpen={isStockImportModalOpen} onClose={() => setIsStockImportModalOpen(false)} title="Import Broker Holdings (CSV/Excel)">
        <form onSubmit={handleBrokerImport} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Select Broker Format</label>
            <select
              value={selectedBrokerName}
              onChange={(e) => setSelectedBrokerName(e.target.value)}
              className="select-field text-sm rounded-xl"
            >
              <option value="Zerodha Kite">Zerodha Kite (Holdings CSV)</option>
              <option value="Groww">Groww (Holdings Excel/CSV)</option>
              <option value="Upstox">Upstox (Holdings CSV)</option>
              <option value="Angel One">Angel One (Holdings File)</option>
              <option value="ICICI Direct">ICICI Direct</option>
            </select>
          </div>

          <div className="border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-2xl p-6 text-center">
            <FileSpreadsheet className="w-10 h-10 text-blue-500 mx-auto mb-2" />
            <input
              type="file"
              accept=".csv, .xlsx, .xls"
              required
              onChange={(e) => setBrokerFile(e.target.files?.[0] || null)}
              className="text-xs text-slate-500"
            />
          </div>

          <button
            type="submit"
            disabled={brokerUploading || !brokerFile}
            className="w-full py-3 rounded-xl bg-blue-500 hover:bg-blue-600 text-white font-bold text-sm transition shadow-md disabled:opacity-50"
          >
            {brokerUploading ? 'Importing Demat Holdings...' : 'Upload & Update Stocks'}
          </button>
        </form>
      </Modal>

      {/* Add Single Stock Modal */}
      <Modal isOpen={isAddStockModalOpen} onClose={() => setIsAddStockModalOpen(false)} title="Record Stock Holding">
        <form onSubmit={handleAddStock} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Symbol (e.g. RELIANCE)</label>
              <input
                type="text"
                required
                value={stockSymbol}
                onChange={(e) => setStockSymbol(e.target.value)}
                placeholder="RELIANCE"
                className="input-field text-sm rounded-xl uppercase"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Broker</label>
              <input
                type="text"
                value={stockBroker}
                onChange={(e) => setStockBroker(e.target.value)}
                placeholder="Zerodha Kite"
                className="input-field text-sm rounded-xl"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Quantity</label>
              <input
                type="number"
                required
                value={stockQty}
                onChange={(e) => setStockQty(e.target.value)}
                placeholder="10"
                className="input-field text-sm rounded-xl"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Avg Buy Price (₹)</label>
              <input
                type="number"
                step="any"
                required
                value={stockBuyPrice}
                onChange={(e) => setStockBuyPrice(e.target.value)}
                placeholder="2450"
                className="input-field text-sm rounded-xl"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Current Price (₹)</label>
              <input
                type="number"
                step="any"
                value={stockCurPrice}
                onChange={(e) => setStockCurPrice(e.target.value)}
                placeholder="2780"
                className="input-field text-sm rounded-xl"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-blue-500 hover:bg-blue-600 text-white font-bold text-sm transition shadow-md"
          >
            Save Stock Holding
          </button>
        </form>
      </Modal>

      {/* Connect Broker API Modal */}
      <Modal isOpen={isBrokerModalOpen} onClose={() => setIsBrokerModalOpen(false)} title="Connect Broker API">
        <form onSubmit={handleConnectBroker} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Broker API Provider</label>
            <select
              value={connectBrokerName}
              onChange={(e) => setConnectBrokerName(e.target.value)}
              className="select-field text-sm rounded-xl"
            >
              <option value="Zerodha Kite Connect">Zerodha Kite Connect</option>
              <option value="Upstox API">Upstox Developer API</option>
              <option value="Angel One SmartAPI">Angel One SmartAPI</option>
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">API Key</label>
            <input
              type="text"
              required
              value={connectApiKey}
              onChange={(e) => setConnectApiKey(e.target.value)}
              placeholder="Enter API Key from Broker Portal"
              className="input-field text-sm rounded-xl"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">API Secret / Access Token</label>
            <input
              type="password"
              value={connectApiSecret}
              onChange={(e) => setConnectApiSecret(e.target.value)}
              placeholder="Enter API Secret"
              className="input-field text-sm rounded-xl"
            />
          </div>

          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-indigo-500 hover:bg-indigo-600 text-white font-bold text-sm transition shadow-md"
          >
            Save Connection
          </button>
        </form>
      </Modal>
    </div>
  );
}
