import React from 'react';
import { Loader2 } from 'lucide-react';

export function LoadingSpinner({ message = 'Loading financial records...' }: { message?: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 space-y-3">
      <Loader2 className="w-8 h-8 text-teal-500 animate-spin" />
      <span className="text-sm font-medium text-slate-500 dark:text-slate-400">
        {message}
      </span>
    </div>
  );
}
