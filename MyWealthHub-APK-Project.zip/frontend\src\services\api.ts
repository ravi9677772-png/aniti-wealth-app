import axios, { AxiosInstance, AxiosError, InternalAxiosRequestConfig } from 'axios';
import { API_BASE_URL } from '../config';

const api: AxiosInstance = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 30000,
});

// Request interceptor: attach JWT
api.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    const token = localStorage.getItem('token');
    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error: AxiosError) => Promise.reject(error)
);

// Response interceptor: handle 401
api.interceptors.response.use(
  (response) => response,
  (error: AxiosError) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      // Only redirect if not already on login/register
      if (!window.location.pathname.includes('/login') && !window.location.pathname.includes('/register')) {
        window.location.href = '/login';
      }
    }
    return Promise.reject(error);
  }
);

/* ───────────────────── Auth ───────────────────── */
export const authApi = {
  login: async (credentials: any) => {
    const { data } = await api.post('/auth/login', credentials);
    return data.data;
  },
  register: async (credentials: any) => {
    const { data } = await api.post('/auth/register', credentials);
    return data.data;
  },
  getMe: async () => {
    const { data } = await api.get('/auth/me');
    return data.data;
  },
  changePassword: async (payload: any) => {
    const { data } = await api.post('/auth/change-password', payload);
    return data;
  },
};

/* ───────────────────── Accounts ───────────────────── */
export const accountApi = {
  getAccounts: async () => {
    const { data } = await api.get('/accounts');
    return data.data;
  },
  getAccount: async (id: number | string) => {
    const { data } = await api.get(`/accounts/${id}`);
    return data.data;
  },
  createAccount: async (payload: any) => {
    const { data } = await api.post('/accounts', payload);
    return data.data;
  },
  updateAccount: async (id: number | string, payload: any) => {
    const { data } = await api.put(`/accounts/${id}`, payload);
    return data.data;
  },
  deleteAccount: async (id: number | string) => {
    const { data } = await api.delete(`/accounts/${id}`);
    return data;
  },
  syncAccount: async (id: number | string) => {
    const { data } = await api.post(`/accounts/${id}/sync`);
    return data.data;
  },
};
export const accountsApi = accountApi;

/* ───────────────────── Categories ───────────────────── */
export const categoryApi = {
  getCategories: async (type?: string) => {
    const { data } = await api.get('/categories', { params: { type } });
    return data.data;
  },
  getCategoriesWithSpending: async (month?: string) => {
    const { data } = await api.get('/categories/with-spending', { params: { month } });
    return data.data;
  },
  suggestCategory: async (description: string) => {
    const { data } = await api.post('/categories/suggest', { description });
    return data.data;
  },
  createCategory: async (payload: any) => {
    const { data } = await api.post('/categories', payload);
    return data.data;
  },
  updateCategory: async (id: number | string, payload: any) => {
    const { data } = await api.put(`/categories/${id}`, payload);
    return data.data;
  },
  deleteCategory: async (id: number | string) => {
    const { data } = await api.delete(`/categories/${id}`);
    return data;
  },
};
export const categoriesApi = categoryApi;

/* ───────────────────── Transactions ───────────────────── */
export const transactionApi = {
  getTransactions: async (params?: any) => {
    const { data } = await api.get('/transactions', { params });
    return data;
  },
  getTransaction: async (id: number | string) => {
    const { data } = await api.get(`/transactions/${id}`);
    return data.data;
  },
  createTransaction: async (payload: any) => {
    const { data } = await api.post('/transactions', payload);
    return data.data;
  },
  updateTransaction: async (id: number | string, payload: any) => {
    const { data } = await api.put(`/transactions/${id}`, payload);
    return data.data;
  },
  deleteTransaction: async (id: number | string) => {
    const { data } = await api.delete(`/transactions/${id}`);
    return data;
  },
  parseNaturalLanguage: async (text: string) => {
    const { data } = await api.post('/transactions/parse-natural-language', { text });
    return data.data;
  },
};
export const transactionsApi = transactionApi;

/* ───────────────────── Budgets ───────────────────── */
export const budgetApi = {
  getBudgets: async (month?: string) => {
    const { data } = await api.get('/budgets', { params: { month } });
    return data.data;
  },
  getSummary: async () => {
    const { data } = await api.get('/budgets/summary');
    return data.data;
  },
  createBudget: async (payload: any) => {
    const { data } = await api.post('/budgets', payload);
    return data.data;
  },
  updateBudget: async (id: number | string, payload: any) => {
    const { data } = await api.put(`/budgets/${id}`, payload);
    return data.data;
  },
  deleteBudget: async (id: number | string) => {
    const { data } = await api.delete(`/budgets/${id}`);
    return data;
  },
};
export const budgetsApi = budgetApi;

/* ───────────────────── Assets ───────────────────── */
export const assetApi = {
  getAssets: async () => {
    const { data } = await api.get('/assets');
    return data.data;
  },
  getSummary: async () => {
    const { data } = await api.get('/assets/summary');
    return data.data;
  },
  createAsset: async (payload: any) => {
    const { data } = await api.post('/assets', payload);
    return data.data;
  },
  updateAsset: async (id: number | string, payload: any) => {
    const { data } = await api.put(`/assets/${id}`, payload);
    return data.data;
  },
  deleteAsset: async (id: number | string) => {
    const { data } = await api.delete(`/assets/${id}`);
    return data;
  },
};
export const assetsApi = assetApi;

/* ───────────────────── Liabilities ───────────────────── */
export const liabilityApi = {
  getLiabilities: async () => {
    const { data } = await api.get('/liabilities');
    return data.data;
  },
  getSummary: async () => {
    const { data } = await api.get('/liabilities/summary');
    return data.data;
  },
  createLiability: async (payload: any) => {
    const { data } = await api.post('/liabilities', payload);
    return data.data;
  },
  updateLiability: async (id: number | string, payload: any) => {
    const { data } = await api.put(`/liabilities/${id}`, payload);
    return data.data;
  },
  deleteLiability: async (id: number | string) => {
    const { data } = await api.delete(`/liabilities/${id}`);
    return data;
  },
};
export const liabilitiesApi = liabilityApi;

/* ───────────────────── Goals ───────────────────── */
export const goalApi = {
  getGoals: async () => {
    const { data } = await api.get('/goals');
    return data.data;
  },
  createGoal: async (payload: any) => {
    const { data } = await api.post('/goals', payload);
    return data.data;
  },
  updateGoal: async (id: number | string, payload: any) => {
    const { data } = await api.put(`/goals/${id}`, payload);
    return data.data;
  },
  deleteGoal: async (id: number | string) => {
    const { data } = await api.delete(`/goals/${id}`);
    return data;
  },
};
export const goalsApi = goalApi;

/* ───────────────────── Dashboard ───────────────────── */
export const dashboardApi = {
  getDashboard: async () => {
    const { data } = await api.get('/dashboard');
    return data.data;
  },
};

/* ───────────────────── Reports ───────────────────── */
export const reportApi = {
  getReports: async (startDate?: string, endDate?: string) => {
    const { data } = await api.get('/reports', { params: { startDate, endDate } });
    return data.data;
  },
};
export const reportsApi = reportApi;

/* ───────────────────── AI Assistant ───────────────────── */
export const assistantApi = {
  query: async (queryText: string) => {
    const { data } = await api.post('/assistant/query', { query: queryText });
    return data.data;
  },
};

/* ───────────────────── Import ───────────────────── */
export const importApi = {
  uploadFile: async (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    const { data } = await api.post('/import/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return data.data;
  },
  previewImport: async (accountId: number, records: any[], mapping: any) => {
    const { data } = await api.post('/import/preview', { accountId, records, mapping });
    return data.data;
  },
  executeImport: async (accountId: number, fileName: string, fileType: string, records: any[], mapping: any) => {
    const { data } = await api.post('/import/execute', { accountId, fileName, fileType, records, mapping });
    return data.data;
  },
  getImportHistory: async () => {
    const { data } = await api.get('/import/history');
    return data.data;
  },
  reverseImport: async (batchId: string) => {
    const { data } = await api.post(`/import/reverse/${batchId}`);
    return data;
  },
};

/* ───────────────────── Insurance & Dues ───────────────────── */
export const insuranceApi = {
  getPolicies: async () => {
    const { data } = await api.get('/insurance');
    return data.data;
  },
  getUpcoming: async (days: number = 60) => {
    const { data } = await api.get('/insurance/upcoming', { params: { days } });
    return data.data;
  },
  getSummary: async () => {
    const { data } = await api.get('/insurance/summary');
    return data.data;
  },
  createPolicy: async (payload: any) => {
    const { data } = await api.post('/insurance', payload);
    return data.data;
  },
  updatePolicy: async (id: number | string, payload: any) => {
    const { data } = await api.put(`/insurance/${id}`, payload);
    return data.data;
  },
  deletePolicy: async (id: number | string) => {
    const { data } = await api.delete(`/insurance/${id}`);
    return data;
  },
  markPaid: async (id: number | string, accountId?: number) => {
    const { data } = await api.post(`/insurance/${id}/mark-paid`, { accountId });
    return data;
  },
};

/* ───────────────────── Investments (Mutual Funds & Stocks) ───────────────────── */
export const investmentsApi = {
  getMutualFunds: async () => {
    const { data } = await api.get('/investments/mf');
    return data.data;
  },
  addMutualFund: async (payload: any) => {
    const { data } = await api.post('/investments/mf', payload);
    return data.data;
  },
  deleteMutualFund: async (id: number | string) => {
    const { data } = await api.delete(`/investments/mf/${id}`);
    return data;
  },
  importCasStatement: async (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    const { data } = await api.post('/investments/mf/import-cas', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return data;
  },
  getStocks: async () => {
    const { data } = await api.get('/investments/stocks');
    return data.data;
  },
  addStock: async (payload: any) => {
    const { data } = await api.post('/investments/stocks', payload);
    return data.data;
  },
  deleteStock: async (id: number | string) => {
    const { data } = await api.delete(`/investments/stocks/${id}`);
    return data;
  },
  importBrokerHoldings: async (file: File, brokerName: string) => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('brokerName', brokerName);
    const { data } = await api.post('/investments/stocks/import-broker', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return data;
  },
  getBrokers: async () => {
    const { data } = await api.get('/investments/brokers');
    return data.data;
  },
  connectBroker: async (brokerName: string, apiKey: string, apiSecret?: string) => {
    const { data } = await api.post('/investments/brokers/connect', { brokerName, apiKey, apiSecret });
    return data;
  },
  getSummary: async () => {
    const { data } = await api.get('/investments/summary');
    return data.data;
  },
};

export default api;
