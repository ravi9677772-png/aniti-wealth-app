import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  ArrowLeft,
  Check,
  Save,
  RotateCcw,
  Sparkles,
  Loader2,
  Calendar,
  CreditCard,
  Tag,
  Building,
} from 'lucide-react';
import { transactionApi, accountApi, categoryApi } from '../services/api';
import { Account, Category, TransactionType, PaymentMode } from '../types';

export function AddTransactionPage() {
  const navigate = useNavigate();
  const location = useLocation();

  // Check if routed with a natural language draft or existing transaction to edit
  const draft = location.state?.draft;
  const existingTx = location.state?.transaction;

  const [accounts, setAccounts] = useState<Account[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Form Fields
  const [type, setType] = useState<TransactionType>(
    existingTx?.type || draft?.type || 'expense'
  );
  const [amount, setAmount] = useState<string>(
    existingTx ? String(existingTx.amount / 100) : draft?.amount ? String(draft.amount) : ''
  );
  const [date, setDate] = useState<string>(
    existingTx?.date?.slice(0, 10) || draft?.date || new Date().toISOString().slice(0, 10)
  );
  const [accountId, setAccountId] = useState<string>(
    existingTx?.account_id ? String(existingTx.account_id) : draft?.accountId ? String(draft.accountId) : ''
  );
  const [categoryId, setCategoryId] = useState<string>(
    existingTx?.category_id ? String(existingTx.category_id) : draft?.categoryId ? String(draft.categoryId) : ''
  );
  const [transferToAccountId, setTransferToAccountId] = useState<string>(
    existingTx?.transfer_to_account_id ? String(existingTx.transfer_to_account_id) : ''
  );
  const [merchant, setMerchant] = useState<string>(
    existingTx?.merchant || draft?.merchant || ''
  );
  const [description, setDescription] = useState<string>(
    existingTx?.description || draft?.description || ''
  );
  const [paymentMode, setPaymentMode] = useState<PaymentMode>(
    existingTx?.payment_mode || draft?.paymentMode || 'upi'
  );
  const [referenceNumber, setReferenceNumber] = useState<string>(
    existingTx?.reference_number || ''
  );
  const [notes, setNotes] = useState<string>(existingTx?.notes || '');
  const [isRecurring, setIsRecurring] = useState<boolean>(
    existingTx?.is_recurring === 1 || false
  );
  const [recurringFrequency, setRecurringFrequency] = useState<string>(
    existingTx?.recurring_frequency || 'monthly'
  );

  useEffect(() => {
    const init = async () => {
      setLoading(true);
      try {
        const [accs, cats] = await Promise.all([
          accountApi.getAccounts(),
          categoryApi.getCategories(),
        ]);
        setAccounts(accs || []);
        setCategories(cats || []);

        if (!accountId && accs && accs.length > 0) {
          setAccountId(String(accs[0].id));
        }
      } catch (err) {
        console.error('Error initializing form:', err);
      } finally {
        setLoading(false);
      }
    };
    init();
  }, []);

  const handleSave = async (saveAndNew = false) => {
    if (!amount || parseFloat(amount) <= 0) {
      setError('Please enter a valid amount greater than zero.');
      return;
    }
    if (!accountId) {
      setError('Please select an account.');
      return;
    }
    if (type === 'transfer' && (!transferToAccountId || transferToAccountId === accountId)) {
      setError('Please select a different destination account for transfers.');
      return;
    }

    setSaving(true);
    setError(null);

    const payload = {
      accountId: Number(accountId),
      categoryId: categoryId ? Number(categoryId) : undefined,
      type,
      amount: parseFloat(amount),
      date,
      description,
      merchant,
      paymentMode,
      referenceNumber,
      notes,
      isRecurring: isRecurring ? 1 : 0,
      recurringFrequency: isRecurring ? recurringFrequency : undefined,
      transferToAccountId: type === 'transfer' ? Number(transferToAccountId) : undefined,
    };

    try {
      if (existingTx) {
        await transactionApi.updateTransaction(existingTx.id, payload as any);
      } else {
        await transactionApi.createTransaction(payload as any);
      }

      if (saveAndNew) {
        setAmount('');
        setDescription('');
        setMerchant('');
        setNotes('');
        setReferenceNumber('');
        alert('Transaction saved! Enter the next one.');
      } else {
        navigate('/transactions');
      }
    } catch (err: any) {
      setError(err?.response?.data?.error || 'Failed to save transaction.');
    } finally {
      setSaving(false);
    }
  };

  const filteredCategories = categories.filter((c) =>
    type === 'income' ? c.type === 'income' : c.type === 'expense'
  );

  return (
    <div className="max-w-2xl mx-auto space-y-5">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-1.5 text-xs md:text-sm font-semibold text-slate-500 hover:text-slate-800 dark:hover:text-white transition"
        >
          <ArrowLeft size={16} />
          <span>Back</span>
        </button>

        <h2 className="text-lg font-bold text-slate-800 dark:text-white">
          {existingTx ? 'Edit Transaction' : 'Record Transaction'}
        </h2>
        <div className="w-16" />
      </div>

      {draft && (
        <div className="p-3.5 rounded-2xl bg-teal-500/10 border border-teal-500/20 text-xs text-teal-800 dark:text-teal-200 flex items-center gap-2">
          <Sparkles size={16} className="text-teal-500 shrink-0" />
          <span>Draft populated from natural language. Review and confirm details below.</span>
        </div>
      )}

      {error && (
        <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-xs font-semibold text-rose-600 dark:text-rose-400">
          {error}
        </div>
      )}

      {/* Main Form Container */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 md:p-8 border border-slate-200/80 dark:border-slate-800 shadow-md space-y-6">
        {/* Type Toggle Tabs */}
        <div className="grid grid-cols-4 p-1 rounded-2xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-600 dark:text-slate-400">
          {(['expense', 'income', 'transfer', 'refund'] as TransactionType[]).map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => {
                setType(t);
                setCategoryId('');
              }}
              className={`py-2.5 rounded-xl capitalize transition ${
                type === t
                  ? t === 'income'
                    ? 'bg-emerald-500 text-white shadow-sm'
                    : t === 'expense'
                    ? 'bg-rose-500 text-white shadow-sm'
                    : 'bg-teal-500 text-white shadow-sm'
                  : 'hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        {/* Large Amount Input */}
        <div className="text-center py-2 space-y-1">
          <label className="text-xs text-slate-400 uppercase tracking-widest font-bold">
            Amount (INR)
          </label>
          <div className="relative inline-flex items-center justify-center max-w-xs mx-auto">
            <span className="text-3xl md:text-4xl font-bold font-mono text-slate-400 mr-1.5">
              ₹
            </span>
            <input
              type="number"
              step="any"
              required
              autoFocus
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
              className="w-full text-center text-3xl md:text-4xl font-black font-mono tracking-tight bg-transparent text-slate-900 dark:text-white focus:outline-none placeholder-slate-300 dark:placeholder-slate-700"
            />
          </div>
        </div>

        {/* Core Details Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Account */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 flex items-center gap-1.5">
              <CreditCard size={14} className="text-teal-500" />
              <span>{type === 'transfer' ? 'From Account' : 'Account'}</span>
            </label>
            <select
              value={accountId}
              onChange={(e) => setAccountId(e.target.value)}
              className="select-field text-sm rounded-xl"
            >
              <option value="">Select Account</option>
              {accounts.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.name} ({a.bank_name || a.type})
                </option>
              ))}
            </select>
          </div>

          {/* Transfer To Account (if type is transfer) */}
          {type === 'transfer' ? (
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 flex items-center gap-1.5">
                <CreditCard size={14} className="text-blue-500" />
                <span>To Account</span>
              </label>
              <select
                value={transferToAccountId}
                onChange={(e) => setTransferToAccountId(e.target.value)}
                className="select-field text-sm rounded-xl"
              >
                <option value="">Select Destination Account</option>
                {accounts
                  .filter((a) => String(a.id) !== accountId)
                  .map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.name}
                    </option>
                  ))}
              </select>
            </div>
          ) : (
            /* Category */
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 flex items-center gap-1.5">
                <Tag size={14} className="text-teal-500" />
                <span>Category</span>
              </label>
              <select
                value={categoryId}
                onChange={(e) => setCategoryId(e.target.value)}
                className="select-field text-sm rounded-xl"
              >
                <option value="">Select Category</option>
                {filteredCategories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.icon || '📁'} {c.name}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Date */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 flex items-center gap-1.5">
              <Calendar size={14} className="text-teal-500" />
              <span>Date</span>
            </label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="input-field text-sm rounded-xl"
            />
          </div>

          {/* Payment Mode */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">
              Payment Mode
            </label>
            <select
              value={paymentMode}
              onChange={(e) => setPaymentMode(e.target.value as PaymentMode)}
              className="select-field text-sm rounded-xl uppercase"
            >
              <option value="upi">UPI (GPay / PhonePe / Paytm)</option>
              <option value="card">Debit / Credit Card</option>
              <option value="imps">IMPS</option>
              <option value="neft">NEFT</option>
              <option value="rtgs">RTGS</option>
              <option value="cash">Cash</option>
              <option value="other">Other</option>
            </select>
          </div>

          {/* Merchant / Payee */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">
              Merchant / Payee / Source
            </label>
            <input
              type="text"
              value={merchant}
              onChange={(e) => setMerchant(e.target.value)}
              placeholder="e.g. Swiggy, Amazon, DMart, Infosys"
              className="input-field text-sm rounded-xl"
            />
          </div>

          {/* Description */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">
              Description / Narration
            </label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Weekly vegetable shopping"
              className="input-field text-sm rounded-xl"
            />
          </div>
        </div>

        {/* Reference Number & Notes */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">
              Ref Number / UPI UTR (Optional)
            </label>
            <input
              type="text"
              value={referenceNumber}
              onChange={(e) => setReferenceNumber(e.target.value)}
              placeholder="e.g. 428192819210"
              className="input-field text-sm rounded-xl"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">
              Notes
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Personal notes..."
              className="input-field text-sm rounded-xl"
            />
          </div>
        </div>

        {/* Recurring Toggle */}
        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div>
            <div className="text-sm font-bold text-slate-800 dark:text-white">
              Recurring Transaction
            </div>
            <p className="text-xs text-slate-400">
              Auto-registers for upcoming bills and cash flow forecasts
            </p>
          </div>

          <div className="flex items-center gap-3">
            {isRecurring && (
              <select
                value={recurringFrequency}
                onChange={(e) => setRecurringFrequency(e.target.value)}
                className="select-field text-xs py-1.5 px-3 rounded-lg"
              >
                <option value="monthly">Monthly</option>
                <option value="weekly">Weekly</option>
                <option value="daily">Daily</option>
                <option value="yearly">Yearly</option>
              </select>
            )}

            <input
              type="checkbox"
              checked={isRecurring}
              onChange={(e) => setIsRecurring(e.target.checked)}
              className="w-5 h-5 rounded text-teal-500 focus:ring-teal-500 cursor-pointer"
            />
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3 pt-2">
          <button
            type="button"
            onClick={() => handleSave(false)}
            disabled={saving}
            className="flex-1 py-3.5 rounded-xl bg-teal-500 hover:bg-teal-600 text-white font-bold text-sm transition shadow-lg shadow-teal-500/25 flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {saving ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />}
            <span>{existingTx ? 'Update Transaction' : 'Save Transaction'}</span>
          </button>

          {!existingTx && (
            <button
              type="button"
              onClick={() => handleSave(true)}
              disabled={saving}
              className="py-3.5 px-6 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-semibold text-sm hover:bg-slate-200 dark:hover:bg-slate-700 transition"
            >
              Save & Add Another
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
