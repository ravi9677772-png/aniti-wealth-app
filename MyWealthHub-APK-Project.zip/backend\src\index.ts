// ============================================================================
// My Wealth Hub — Main Express Server Entry Point
// ============================================================================

import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import { initializeDatabase } from './database';
import { authMiddleware } from './middleware/auth';
import { errorHandler } from './middleware/errorHandler';

import authRoutes from './routes/auth';
import accountRoutes from './routes/accounts';
import categoryRoutes from './routes/categories';
import transactionRoutes from './routes/transactions';
import budgetRoutes from './routes/budgets';
import assetRoutes from './routes/assets';
import liabilityRoutes from './routes/liabilities';
import goalRoutes from './routes/goals';
import importRoutes from './routes/import';
import reportRoutes from './routes/reports';
import assistantRoutes from './routes/assistant';
import dashboardRoutes from './routes/dashboard';
import insuranceRoutes from './routes/insurance';
import investmentRoutes from './routes/investments';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

// CORS configuration
app.use(
  cors({
    origin: '*',
    credentials: true,
  })
);

app.use(express.json({ limit: '15mb' }));
app.use(express.urlencoded({ extended: true, limit: '15mb' }));

// Initialize persistent SQLite database
const dbPath = process.env.DB_PATH || path.join(__dirname, '../data/wealth-hub.db');
initializeDatabase(dbPath);
console.log(`[My Wealth Hub] SQLite Database initialized at: ${dbPath}`);

// Health check
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    app: 'My Wealth Hub',
    timestamp: new Date().toISOString(),
    timezone: 'Asia/Kolkata',
  });
});

// Mount Routes
app.use('/api/auth', authRoutes);
app.use('/api/accounts', authMiddleware, accountRoutes);
app.use('/api/categories', authMiddleware, categoryRoutes);
app.use('/api/transactions', authMiddleware, transactionRoutes);
app.use('/api/budgets', authMiddleware, budgetRoutes);
app.use('/api/assets', authMiddleware, assetRoutes);
app.use('/api/liabilities', authMiddleware, liabilityRoutes);
app.use('/api/goals', authMiddleware, goalRoutes);
app.use('/api/import', authMiddleware, importRoutes);
app.use('/api/reports', authMiddleware, reportRoutes);
app.use('/api/assistant', authMiddleware, assistantRoutes);
app.use('/api/dashboard', authMiddleware, dashboardRoutes);
app.use('/api/insurance', authMiddleware, insuranceRoutes);
app.use('/api/investments', authMiddleware, investmentRoutes);

// Optional: Serve frontend static build if available
const frontendDist = path.join(__dirname, '../../frontend/dist');
app.use(express.static(frontendDist));
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api')) return next();
  res.sendFile(path.join(frontendDist, 'index.html'), (err) => {
    if (err) {
      res.status(200).send('My Wealth Hub API is running. Start the frontend Vite dev server or build the frontend.');
    }
  });
});

// Global Error Handler
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`[My Wealth Hub] Server listening on http://localhost:${PORT}`);
});

export default app;
