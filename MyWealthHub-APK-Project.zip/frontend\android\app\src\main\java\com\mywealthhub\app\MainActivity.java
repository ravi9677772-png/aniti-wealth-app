package com.mywealthhub.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
