import React, { useState } from 'react';
import { Sparkles, ArrowRight, Loader2 } from 'lucide-react';
import { transactionApi } from '../services/api';

interface NaturalLanguageInputProps {
  onParsed: (draft: any) => void;
}

export function NaturalLanguageInput({ onParsed }: NaturalLanguageInputProps) {
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const examples = [
    'Spent ₹1,000 on petrol today',
    'Received ₹75,000 salary',
    'Paid ₹12,000 for school fees',
    'Swiggy dinner ₹650 yesterday',
  ];

  const handleParse = async (inputStr?: string) => {
    const query = inputStr || text;
    if (!query.trim()) return;

    setLoading(true);
    setError(null);

    try {
      const result = await transactionApi.parseNaturalLanguage(query);
      if (result) {
        onParsed(result);
        setText('');
      }
    } catch (err: any) {
      setError(err?.response?.data?.error || 'Could not understand transaction prompt.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-4 md:p-5 rounded-2xl bg-gradient-to-r from-teal-500/10 via-slate-900/5 to-teal-500/5 dark:from-teal-950/40 dark:via-slate-900 dark:to-teal-950/20 border border-teal-500/20 shadow-sm space-y-3">
      <div className="flex items-center gap-2 text-teal-600 dark:text-teal-400 font-bold text-sm">
        <Sparkles size={16} />
        <span>Quick Entry via Natural Language</span>
      </div>

      <div className="flex gap-2">
        <input
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleParse()}
          placeholder="e.g. Spent ₹1,000 on petrol today or Received ₹75,000 salary"
          className="flex-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
        />
        <button
          onClick={() => handleParse()}
          disabled={loading || !text.trim()}
          className="px-4 py-2.5 rounded-xl bg-teal-500 text-white font-semibold text-sm hover:bg-teal-600 active:scale-95 disabled:opacity-50 transition flex items-center gap-1.5 shrink-0"
        >
          {loading ? <Loader2 size={16} className="animate-spin" /> : <ArrowRight size={16} />}
          <span className="hidden sm:inline">Parse</span>
        </button>
      </div>

      {error && <p className="text-xs text-rose-500 font-medium">{error}</p>}

      {/* Suggestion Chips */}
      <div className="flex flex-wrap gap-1.5 pt-1">
        <span className="text-[11px] text-slate-400 self-center mr-1">Try:</span>
        {examples.map((eg, idx) => (
          <button
            key={idx}
            type="button"
            onClick={() => {
              setText(eg);
              handleParse(eg);
            }}
            className="text-[11px] px-2.5 py-1 rounded-lg bg-white/80 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700/80 hover:border-teal-500 hover:text-teal-600 dark:hover:text-teal-400 transition"
          >
            "{eg}"
          </button>
        ))}
      </div>
    </div>
  );
}
