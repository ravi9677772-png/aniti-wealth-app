import React from 'react';
import { formatINR } from '../hooks/useCurrency';

interface BudgetProgressBarProps {
  categoryName: string;
  categoryIcon?: string;
  budgetAmount: number; // paise
  spentAmount: number;  // paise
  remainingAmount: number; // paise
  utilizationPercent: number;
}

export function BudgetProgressBar({
  categoryName,
  categoryIcon,
  budgetAmount,
  spentAmount,
  remainingAmount,
  utilizationPercent,
}: BudgetProgressBarProps) {
  // Alert colors: <50% green, 50-75% teal, 75-90% amber, >=90% rose
  const getColor = () => {
    if (utilizationPercent >= 100) return 'bg-rose-500';
    if (utilizationPercent >= 90) return 'bg-rose-400';
    if (utilizationPercent >= 75) return 'bg-amber-500';
    return 'bg-teal-500';
  };

  const getTextColor = () => {
    if (utilizationPercent >= 100) return 'text-rose-600 dark:text-rose-400';
    if (utilizationPercent >= 75) return 'text-amber-600 dark:text-amber-400';
    return 'text-slate-600 dark:text-slate-300';
  };

  return (
    <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 space-y-2.5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {categoryIcon && <span>{categoryIcon}</span>}
          <span className="font-semibold text-sm text-slate-800 dark:text-slate-200">
            {categoryName}
          </span>
        </div>
        <span className={`text-xs font-mono font-bold ${getTextColor()}`}>
          {utilizationPercent}% spent
        </span>
      </div>

      {/* Bar */}
      <div className="w-full h-2.5 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
        <div
          className={`h-full rounded-full transition-all duration-500 ${getColor()}`}
          style={{ width: `${Math.min(100, utilizationPercent)}%` }}
        />
      </div>

      <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-mono">
        <span>Spent: {formatINR(spentAmount)}</span>
        <span>Limit: {formatINR(budgetAmount)}</span>
      </div>
    </div>
  );
}
