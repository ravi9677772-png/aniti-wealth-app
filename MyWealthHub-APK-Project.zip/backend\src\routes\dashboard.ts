// ============================================================================
// My Wealth Hub — Dashboard Aggregated Route
// ============================================================================

import { Router, Response } from 'express';
import { AuthenticatedRequest } from '../types';
import { getDashboardData } from '../services/analyticsService';

const router = Router();

router.get('/', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  try {
    const dashboard = getDashboardData(userId);
    res.json({ success: true, data: dashboard });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

export default router;
