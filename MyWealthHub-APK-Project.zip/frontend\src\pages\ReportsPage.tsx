import React, { useState, useEffect } from 'react';
import { FileSpreadsheet, Download, Calendar, TrendingUp, TrendingDown, Layers } from 'lucide-react';
import { reportApi } from '../services/api';
import { IncomeExpenseChart } from '../components/Charts/IncomeExpenseChart';
import { CategoryPieChart } from '../components/Charts/CategoryPieChart';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { formatINR } from '../hooks/useCurrency';

export function ReportsPage() {
  const [data, setData] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const loadReport = async () => {
    try {
      setLoading(true);
      const res = await reportApi.getReports(startDate || undefined, endDate || undefined);
      setData(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadReport();
  }, [startDate, endDate]);

  const handleExportCSV = () => {
    if (!data?.categoryBreakdown) return;
    const headers = ['Category', 'Amount (INR)', 'Transactions Count'];
    const rows = data.categoryBreakdown.map((c: any) => [
      `"${c.category}"`,
      (c.amount / 100).toFixed(2),
      c.count,
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e: any) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `wealth_hub_report_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (loading) return <LoadingSpinner message="Synthesizing financial reports..." />;

  const summary = data?.summary || { totalIncome: 0, totalExpense: 0, netSavings: 0, totalTransactions: 0 };

  return (
    <div className="space-y-6">
      {/* Top Filter and Export Bar */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-500/10 text-teal-600 dark:text-teal-400">
            <FileSpreadsheet size={20} />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-800 dark:text-white">
              Financial Intelligence Report
            </h2>
            <p className="text-xs text-slate-400">Cash flow and category spending telemetry</p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <input
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="input-field text-xs py-2 px-3 rounded-lg w-auto"
            title="Start date"
          />
          <span className="text-slate-400 text-xs">to</span>
          <input
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className="input-field text-xs py-2 px-3 rounded-lg w-auto"
            title="End date"
          />

          <button
            onClick={handleExportCSV}
            className="px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold flex items-center gap-1.5 transition"
          >
            <Download size={14} />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* KPI Summary Tiles */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800">
          <span className="text-xs text-slate-400 font-medium">Total Inflows</span>
          <div className="text-xl font-bold font-mono text-emerald-500 mt-1">
            {formatINR(summary.totalIncome)}
          </div>
        </div>
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800">
          <span className="text-xs text-slate-400 font-medium">Total Outflows</span>
          <div className="text-xl font-bold font-mono text-rose-500 mt-1">
            {formatINR(summary.totalExpense)}
          </div>
        </div>
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800">
          <span className="text-xs text-slate-400 font-medium">Net Retained Surplus</span>
          <div className="text-xl font-bold font-mono text-teal-500 mt-1">
            {formatINR(summary.netSavings)}
          </div>
        </div>
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800">
          <span className="text-xs text-slate-400 font-medium">Recorded Events</span>
          <div className="text-xl font-bold font-mono text-slate-700 dark:text-slate-200 mt-1">
            {summary.totalTransactions} transactions
          </div>
        </div>
      </div>

      {/* Category Breakdown Table */}
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
        <h3 className="font-bold text-sm text-slate-800 dark:text-white">
          Category Spending Hierarchy
        </h3>

        {data?.categoryBreakdown && data.categoryBreakdown.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-400 font-mono">
                  <th className="py-2.5 px-3">Category</th>
                  <th className="py-2.5 px-3">Volume</th>
                  <th className="py-2.5 px-3 text-right">Total Amount</th>
                  <th className="py-2.5 px-3 text-right">Share</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-mono">
                {data.categoryBreakdown.map((c: any, i: number) => {
                  const share = summary.totalExpense > 0 ? Math.round((c.amount / summary.totalExpense) * 100) : 0;
                  return (
                    <tr key={i} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="py-3 px-3 font-sans font-semibold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                        <span>{c.icon || '📁'}</span>
                        <span>{c.category}</span>
                      </td>
                      <td className="py-3 px-3 text-slate-500">{c.count} transactions</td>
                      <td className="py-3 px-3 text-right font-bold text-slate-900 dark:text-white">
                        {formatINR(c.amount)}
                      </td>
                      <td className="py-3 px-3 text-right">
                        <span className="px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold">
                          {share}%
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="py-8 text-center text-xs text-slate-400">
            No expense breakdown records in selected range.
          </div>
        )}
      </div>
    </div>
  );
}
