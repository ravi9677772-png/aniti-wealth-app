// ============================================================================
// My Wealth Hub — Accounts Routes
// ============================================================================

import { Router, Response } from 'express';
import { getDb } from '../database';
import { AuthenticatedRequest, rupeesToPaise } from '../types';

const router = Router();

// List accounts
router.get('/', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const db = getDb();
  const accounts = db
    .prepare('SELECT * FROM accounts WHERE user_id = ? ORDER BY is_active DESC, name ASC')
    .all(userId);
  res.json({ success: true, data: accounts });
});

// Get single account
router.get('/:id', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const db = getDb();
  const account = db
    .prepare('SELECT * FROM accounts WHERE id = ? AND user_id = ?')
    .get(req.params.id, userId);

  if (!account) {
    res.status(404).json({ success: false, error: 'Account not found' });
    return;
  }
  res.json({ success: true, data: account });
});

// Create account
router.post('/', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const { name, type, bankName, accountNumberMasked, balance, currency } = req.body;

  if (!name || !type) {
    res.status(400).json({ success: false, error: 'Name and type are required' });
    return;
  }

  const balancePaise = balance !== undefined ? rupeesToPaise(Number(balance)) : 0;
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO accounts (user_id, name, type, bank_name, account_number_masked, balance, currency)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);

  const result = stmt.run(
    userId,
    name,
    type,
    bankName || null,
    accountNumberMasked || null,
    balancePaise,
    currency || 'INR'
  );

  const newAccount = db.prepare('SELECT * FROM accounts WHERE id = ?').get(result.lastInsertRowid);
  res.status(201).json({ success: true, data: newAccount });
});

// Update account
router.put('/:id', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const db = getDb();
  const { name, type, bankName, accountNumberMasked, balance, isActive } = req.body;

  const existing = db
    .prepare('SELECT * FROM accounts WHERE id = ? AND user_id = ?')
    .get(req.params.id, userId) as any;

  if (!existing) {
    res.status(404).json({ success: false, error: 'Account not found' });
    return;
  }

  const updatedName = name ?? existing.name;
  const updatedType = type ?? existing.type;
  const updatedBank = bankName ?? existing.bank_name;
  const updatedAccNum = accountNumberMasked ?? existing.account_number_masked;
  const updatedBalance = balance !== undefined ? rupeesToPaise(Number(balance)) : existing.balance;
  const updatedActive = isActive !== undefined ? (isActive ? 1 : 0) : existing.is_active;

  db.prepare(`
    UPDATE accounts 
    SET name = ?, type = ?, bank_name = ?, account_number_masked = ?, balance = ?, is_active = ?, updated_at = CURRENT_TIMESTAMP
    WHERE id = ? AND user_id = ?
  `).run(updatedName, updatedType, updatedBank, updatedAccNum, updatedBalance, updatedActive, req.params.id, userId);

  const updated = db.prepare('SELECT * FROM accounts WHERE id = ?').get(req.params.id);
  res.json({ success: true, data: updated });
});

// Delete account (or deactivate)
router.delete('/:id', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const db = getDb();

  // Check if account has transactions
  const txCount = db
    .prepare('SELECT COUNT(*) as count FROM transactions WHERE account_id = ?')
    .get(req.params.id) as { count: number };

  if (txCount.count > 0) {
    // Soft delete/deactivate instead of breaking transactions
    db.prepare('UPDATE accounts SET is_active = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?')
      .run(req.params.id, userId);
    res.json({ success: true, message: 'Account has existing transactions and has been deactivated.' });
    return;
  }

  db.prepare('DELETE FROM accounts WHERE id = ? AND user_id = ?').run(req.params.id, userId);
  res.json({ success: true, message: 'Account deleted.' });
});

// Manual Sync account balance trigger
router.post('/:id/sync', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const db = getDb();
  db.prepare('UPDATE accounts SET last_synced_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?')
    .run(req.params.id, userId);
  const account = db.prepare('SELECT * FROM accounts WHERE id = ?').get(req.params.id);
  res.json({ success: true, message: 'Account synced successfully', data: account });
});

export default router;
