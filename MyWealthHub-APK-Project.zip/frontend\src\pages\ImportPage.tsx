import React, { useState, useEffect } from 'react';
import {
  UploadCloud,
  FileSpreadsheet,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  ArrowRight,
  Loader2,
  Building2,
  Table,
} from 'lucide-react';
import { importApi, accountApi } from '../services/api';
import { Account, ImportPreview, ImportHistory } from '../types';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { formatINR } from '../hooks/useCurrency';

export function ImportPage() {
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [selectedAccountId, setSelectedAccountId] = useState<string>('');
  const [file, setFile] = useState<File | null>(null);
  const [uploadResult, setUploadResult] = useState<any | null>(null);

  // Column Mapping
  const [dateCol, setDateCol] = useState('');
  const [descCol, setDescCol] = useState('');
  const [amountCol, setAmountCol] = useState('');
  const [debitCol, setDebitCol] = useState('');
  const [creditCol, setCreditCol] = useState('');
  const [merchantCol, setMerchantCol] = useState('');
  const [refCol, setRefCol] = useState('');

  // Step wizard: 1 = upload, 2 = map columns, 3 = preview & confirm, 4 = complete
  const [step, setStep] = useState<number>(1);
  const [previewData, setPreviewData] = useState<any | null>(null);
  const [importHistory, setImportHistory] = useState<any[]>([]);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadInitialData = async () => {
    try {
      const [accs, hist] = await Promise.all([
        accountApi.getAccounts(),
        importApi.getImportHistory(),
      ]);
      setAccounts(accs || []);
      setImportHistory(hist || []);
      if (accs && accs.length > 0) setSelectedAccountId(String(accs[0].id));
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    loadInitialData();
  }, []);

  const handleFileUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) {
      setError('Please select a CSV or Excel file.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const res = await importApi.uploadFile(file);
      setUploadResult(res);

      // Auto-guess columns based on common Indian bank statement headers
      const headers = res.headers || [];
      const lowerHeaders = headers.map((h: string) => h.toLowerCase());

      const findCol = (terms: string[]) => {
        const idx = lowerHeaders.findIndex((h: string) => terms.some((t) => h.includes(t)));
        return idx !== -1 ? headers[idx] : '';
      };

      setDateCol(findCol(['date', 'txn date', 'value date']));
      setDescCol(findCol(['narration', 'description', 'particulars', 'remarks']));
      setDebitCol(findCol(['debit', 'dr', 'withdrawal']));
      setCreditCol(findCol(['credit', 'cr', 'deposit']));
      setAmountCol(findCol(['amount', 'txn amount']));
      setRefCol(findCol(['ref', 'chq', 'cheque', 'reference', 'utr']));

      setStep(2);
    } catch (err: any) {
      setError(err?.response?.data?.error || 'Failed to parse file.');
    } finally {
      setLoading(false);
    }
  };

  const handlePreview = async () => {
    if (!dateCol || !descCol || (!amountCol && (!debitCol || !creditCol))) {
      setError('Please map Date, Description, and either Amount or Debit/Credit columns.');
      return;
    }

    setLoading(true);
    setError(null);

    const mapping = {
      date: dateCol,
      description: descCol,
      amount: amountCol || undefined,
      debit: debitCol || undefined,
      credit: creditCol || undefined,
      merchant: merchantCol || undefined,
      referenceNumber: refCol || undefined,
    };

    try {
      const res = await importApi.previewImport(
        Number(selectedAccountId),
        uploadResult.records,
        mapping
      );
      setPreviewData(res);
      setStep(3);
    } catch (err: any) {
      setError(err?.response?.data?.error || 'Failed to generate preview.');
    } finally {
      setLoading(false);
    }
  };

  const handleExecuteImport = async () => {
    setLoading(true);
    setError(null);

    const mapping = {
      date: dateCol,
      description: descCol,
      amount: amountCol || undefined,
      debit: debitCol || undefined,
      credit: creditCol || undefined,
      merchant: merchantCol || undefined,
      referenceNumber: refCol || undefined,
    };

    try {
      await importApi.executeImport(
        Number(selectedAccountId),
        uploadResult.fileName,
        uploadResult.fileType,
        uploadResult.records,
        mapping
      );
      setStep(4);
      loadInitialData();
    } catch (err: any) {
      setError(err?.response?.data?.error || 'Import execution failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleReverseBatch = async (batchId: string) => {
    if (!window.confirm('Reverse this import batch? All its transactions will be deleted and balances returned.')) return;
    try {
      await importApi.reverseImport(batchId);
      alert('Batch reversed successfully.');
      loadInitialData();
    } catch (err: any) {
      alert(err?.response?.data?.error || 'Failed to reverse batch.');
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Aggregator Status Notice */}
      <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-800 dark:text-amber-300 flex items-start gap-3">
        <Building2 size={18} className="shrink-0 text-amber-600 dark:text-amber-400 mt-0.5" />
        <div>
          <span className="font-bold">Indian Bank Statement Processing:</span> Because direct bank API feeds require RBI-licensed Account Aggregator institutional access, this working statement ingestion system parses CSV and Excel statements from HDFC, SBI, ICICI, Axis, Kotak, Zerodha, and other Indian banks with automated deduplication and category detection.
        </div>
      </div>

      {error && (
        <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-xs font-semibold text-rose-600">
          {error}
        </div>
      )}

      {/* Step Wizard Container */}
      <div className="p-6 md:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-md space-y-6">
        {/* Wizard Steps Tracker */}
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4 text-xs font-bold text-slate-400 font-mono">
          <span className={step >= 1 ? 'text-teal-500' : ''}>1. Upload Statement</span>
          <span>→</span>
          <span className={step >= 2 ? 'text-teal-500' : ''}>2. Column Mapping</span>
          <span>→</span>
          <span className={step >= 3 ? 'text-teal-500' : ''}>3. Verify & Deduplicate</span>
          <span>→</span>
          <span className={step >= 4 ? 'text-teal-500' : ''}>4. Completed</span>
        </div>

        {/* Step 1: Upload */}
        {step === 1 && (
          <form onSubmit={handleFileUpload} className="space-y-5">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">
                Target Bank Account
              </label>
              <select
                value={selectedAccountId}
                onChange={(e) => setSelectedAccountId(e.target.value)}
                className="select-field text-sm rounded-xl max-w-md"
              >
                {accounts.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.name} ({a.bank_name || a.type})
                  </option>
                ))}
              </select>
            </div>

            <div className="border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-3xl p-8 md:p-12 text-center hover:border-teal-500 transition cursor-pointer">
              <FileSpreadsheet className="w-12 h-12 text-teal-500 mx-auto mb-3" />
              <div className="text-sm font-bold text-slate-800 dark:text-white">
                Select CSV or Excel bank statement
              </div>
              <p className="text-xs text-slate-400 mt-1">Supports .csv, .xlsx, .xls</p>
              <input
                type="file"
                accept=".csv, .xlsx, .xls"
                onChange={(e) => setFile(e.target.files?.[0] || null)}
                className="mt-4 text-xs text-slate-500"
              />
            </div>

            <button
              type="submit"
              disabled={loading || !file}
              className="w-full py-3.5 rounded-xl bg-teal-500 hover:bg-teal-600 text-white font-bold text-sm transition shadow-md disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {loading ? <Loader2 size={18} className="animate-spin" /> : <UploadCloud size={18} />}
              <span>Inspect File & Map Columns</span>
            </button>
          </form>
        )}

        {/* Step 2: Column Mapping */}
        {step === 2 && uploadResult && (
          <div className="space-y-5">
            <div>
              <h3 className="font-bold text-sm text-slate-800 dark:text-white">
                Map Statement Columns
              </h3>
              <p className="text-xs text-slate-400">
                Found {uploadResult.headers.length} columns in {uploadResult.fileName} ({uploadResult.totalRows} rows).
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">
                  Date Column *
                </label>
                <select
                  value={dateCol}
                  onChange={(e) => setDateCol(e.target.value)}
                  className="select-field text-sm rounded-xl"
                >
                  <option value="">Select column</option>
                  {uploadResult.headers.map((h: string) => (
                    <option key={h} value={h}>{h}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">
                  Description / Narration Column *
                </label>
                <select
                  value={descCol}
                  onChange={(e) => setDescCol(e.target.value)}
                  className="select-field text-sm rounded-xl"
                >
                  <option value="">Select column</option>
                  {uploadResult.headers.map((h: string) => (
                    <option key={h} value={h}>{h}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">
                  Debit / Withdrawal Column (If separate)
                </label>
                <select
                  value={debitCol}
                  onChange={(e) => setDebitCol(e.target.value)}
                  className="select-field text-sm rounded-xl"
                >
                  <option value="">None / Single amount column</option>
                  {uploadResult.headers.map((h: string) => (
                    <option key={h} value={h}>{h}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">
                  Credit / Deposit Column (If separate)
                </label>
                <select
                  value={creditCol}
                  onChange={(e) => setCreditCol(e.target.value)}
                  className="select-field text-sm rounded-xl"
                >
                  <option value="">None / Single amount column</option>
                  {uploadResult.headers.map((h: string) => (
                    <option key={h} value={h}>{h}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">
                  Net Amount Column (If single)
                </label>
                <select
                  value={amountCol}
                  onChange={(e) => setAmountCol(e.target.value)}
                  className="select-field text-sm rounded-xl"
                >
                  <option value="">None / Uses Debit & Credit</option>
                  {uploadResult.headers.map((h: string) => (
                    <option key={h} value={h}>{h}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">
                  Reference / UTR Column (Optional)
                </label>
                <select
                  value={refCol}
                  onChange={(e) => setRefCol(e.target.value)}
                  className="select-field text-sm rounded-xl"
                >
                  <option value="">None</option>
                  {uploadResult.headers.map((h: string) => (
                    <option key={h} value={h}>{h}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="py-3 px-6 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-600 dark:text-slate-300"
              >
                Back
              </button>
              <button
                type="button"
                onClick={handlePreview}
                disabled={loading}
                className="flex-1 py-3 rounded-xl bg-teal-500 hover:bg-teal-600 text-white font-bold text-sm transition shadow-md flex items-center justify-center gap-2"
              >
                {loading ? <Loader2 size={18} className="animate-spin" /> : <ArrowRight size={18} />}
                <span>Preview & Check Duplicates</span>
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Preview */}
        {step === 3 && previewData && (
          <div className="space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h3 className="font-bold text-sm text-slate-800 dark:text-white">
                  Preview Verification
                </h3>
                <p className="text-xs text-slate-400">
                  Duplicates will be automatically skipped to prevent double entries.
                </p>
              </div>

              <div className="flex gap-2 text-xs font-mono">
                <span className="px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-600 font-bold">
                  {previewData.preview.filter((p: any) => !p.isDuplicate && !p.error).length} Ready
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-amber-50 text-amber-600 font-bold">
                  {previewData.stats.duplicates} Duplicates
                </span>
              </div>
            </div>

            {/* Preview Table */}
            <div className="max-h-72 overflow-y-auto border border-slate-100 dark:border-slate-800 rounded-2xl">
              <table className="w-full text-xs text-left">
                <thead className="sticky top-0 bg-slate-50 dark:bg-slate-800 font-mono text-slate-500 border-b border-slate-200 dark:border-slate-700">
                  <tr>
                    <th className="p-2.5">Date</th>
                    <th className="p-2.5">Description</th>
                    <th className="p-2.5">Type</th>
                    <th className="p-2.5 text-right">Amount</th>
                    <th className="p-2.5 text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono">
                  {previewData.preview.slice(0, 20).map((row: any, idx: number) => (
                    <tr key={idx} className={row.isDuplicate ? 'bg-amber-50/50 dark:bg-amber-950/20' : ''}>
                      <td className="p-2.5">{row.date}</td>
                      <td className="p-2.5 font-sans line-clamp-1 max-w-xs">{row.description}</td>
                      <td className="p-2.5 uppercase font-bold text-[10px]">{row.type}</td>
                      <td className="p-2.5 text-right font-bold">₹{row.amount}</td>
                      <td className="p-2.5 text-right">
                        {row.isDuplicate ? (
                          <span className="text-amber-500 font-bold text-[10px]">Duplicate (Skip)</span>
                        ) : row.error ? (
                          <span className="text-rose-500 font-bold text-[10px]">{row.error}</span>
                        ) : (
                          <span className="text-emerald-500 font-bold text-[10px]">Ready</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={() => setStep(2)}
                className="py-3 px-6 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-600 dark:text-slate-300"
              >
                Back
              </button>
              <button
                type="button"
                onClick={handleExecuteImport}
                disabled={loading}
                className="flex-1 py-3 rounded-xl bg-teal-500 hover:bg-teal-600 text-white font-bold text-sm transition shadow-md flex items-center justify-center gap-2"
              >
                {loading ? <Loader2 size={18} className="animate-spin" /> : <CheckCircle2 size={18} />}
                <span>Confirm & Import Records</span>
              </button>
            </div>
          </div>
        )}

        {/* Step 4: Success */}
        {step === 4 && (
          <div className="text-center py-8 space-y-4">
            <div className="w-16 h-16 bg-emerald-500/10 text-emerald-500 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 size={36} />
            </div>
            <h3 className="text-xl font-bold text-slate-800 dark:text-white">
              Statement Imported Successfully
            </h3>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              Records are committed to your SQLite database and account balances have been synchronized.
            </p>
            <div className="flex justify-center gap-3 pt-2">
              <button
                onClick={() => setStep(1)}
                className="px-5 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-200"
              >
                Import Another File
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Import History Table */}
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
        <h3 className="font-bold text-sm text-slate-800 dark:text-white">
          Import Batch History
        </h3>

        {importHistory.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-400 font-mono">
                  <th className="py-2 px-3">Date</th>
                  <th className="py-2 px-3">File</th>
                  <th className="py-2 px-3">Account</th>
                  <th className="py-2 px-3">Imported</th>
                  <th className="py-2 px-3">Status</th>
                  <th className="py-2 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono">
                {importHistory.map((h: any) => (
                  <tr key={h.id}>
                    <td className="py-3 px-3">{h.created_at?.slice(0, 10)}</td>
                    <td className="py-3 px-3 font-sans font-semibold text-slate-800 dark:text-slate-200">
                      {h.file_name}
                    </td>
                    <td className="py-3 px-3 text-slate-500">{h.account_name || 'Account'}</td>
                    <td className="py-3 px-3 font-bold text-teal-600 dark:text-teal-400">
                      {h.imported_records} txs
                    </td>
                    <td className="py-3 px-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                        h.status === 'reversed' ? 'bg-rose-100 text-rose-700' : 'bg-emerald-100 text-emerald-700'
                      }`}>
                        {h.status}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      {h.status !== 'reversed' && (
                        <button
                          onClick={() => handleReverseBatch(h.id)}
                          className="text-xs text-rose-500 hover:underline flex items-center gap-1 justify-end ml-auto"
                        >
                          <RotateCcw size={12} />
                          <span>Reverse</span>
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="py-6 text-center text-xs text-slate-400">
            No previous statement imports found.
          </div>
        )}
      </div>
    </div>
  );
}
