// ============================================================================
// My Wealth Hub — Bank Statement Import Routes (CSV, Excel)
// ============================================================================

import { Router, Response } from 'express';
import multer from 'multer';
import { AuthenticatedRequest } from '../types';
import {
  parseFile,
  generatePreview,
  executeImport,
  reverseImport,
  getImportHistory,
} from '../services/importService';

const router = Router();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
});

// Upload and inspect columns
router.post('/upload', upload.single('file'), (req: AuthenticatedRequest, res: Response): void => {
  if (!req.file) {
    res.status(400).json({ success: false, error: 'No file uploaded' });
    return;
  }

  try {
    const ext = req.file.originalname.split('.').pop()?.toLowerCase() || 'csv';
    const parsed = parseFile(req.file.buffer, ext);

    res.json({
      success: true,
      data: {
        fileName: req.file.originalname,
        fileType: ext,
        headers: parsed.headers,
        sampleRows: parsed.records.slice(0, 5),
        totalRows: parsed.totalRows,
        // In-memory or temporary data token
        records: parsed.records,
      },
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to parse file: ' + err.message });
  }
});

// Preview transactions with column mapping and duplicate detection
router.post('/preview', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const { accountId, records, mapping } = req.body;

  if (!accountId || !records || !mapping) {
    res.status(400).json({ success: false, error: 'Account, records, and column mapping are required' });
    return;
  }

  try {
    const previewResult = generatePreview(userId, Number(accountId), records, mapping);
    res.json({ success: true, data: previewResult });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Execute import
router.post('/execute', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const { accountId, fileName, fileType, records, mapping } = req.body;

  if (!accountId || !records || !mapping) {
    res.status(400).json({ success: false, error: 'Missing required import payload' });
    return;
  }

  try {
    const result = executeImport(
      userId,
      Number(accountId),
      fileName || 'statement.csv',
      fileType || 'csv',
      records,
      mapping
    );
    res.json({ success: true, data: result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Get import batches history
router.get('/history', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  try {
    const history = getImportHistory(userId);
    res.json({ success: true, data: history });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Reverse an import batch
router.post('/reverse/:batchId', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  try {
    const result = reverseImport(userId, req.params.batchId);
    res.json({ success: true, message: `Reversed ${result.reversed} transactions from batch.` });
  } catch (err: any) {
    res.status(400).json({ success: false, error: err.message });
  }
});

export default router;
