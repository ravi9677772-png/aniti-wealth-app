import React from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, Receipt, Plus, PieChart, MoreHorizontal } from 'lucide-react';

export function BottomNav() {
  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 px-2 py-1 safe-bottom shadow-lg">
      <div className="flex items-center justify-around">
        <NavLink
          to="/"
          className={({ isActive }) =>
            `flex flex-col items-center py-1 px-2 text-xs font-medium transition ${
              isActive ? 'text-teal-500 font-bold' : 'text-slate-500 dark:text-slate-400'
            }`
          }
        >
          <LayoutDashboard size={20} />
          <span className="mt-1">Home</span>
        </NavLink>

        <NavLink
          to="/transactions"
          className={({ isActive }) =>
            `flex flex-col items-center py-1 px-2 text-xs font-medium transition ${
              isActive ? 'text-teal-500 font-bold' : 'text-slate-500 dark:text-slate-400'
            }`
          }
        >
          <Receipt size={20} />
          <span className="mt-1">History</span>
        </NavLink>

        {/* Center Floating Action Button */}
        <NavLink
          to="/add-transaction"
          aria-label="Add Transaction"
          className="relative -top-3 w-12 h-12 rounded-full bg-teal-500 text-white flex items-center justify-center shadow-lg shadow-teal-500/30 hover:bg-teal-600 active:scale-95 transition"
        >
          <Plus size={26} strokeWidth={2.5} />
        </NavLink>

        <NavLink
          to="/budgets"
          className={({ isActive }) =>
            `flex flex-col items-center py-1 px-2 text-xs font-medium transition ${
              isActive ? 'text-teal-500 font-bold' : 'text-slate-500 dark:text-slate-400'
            }`
          }
        >
          <PieChart size={20} />
          <span className="mt-1">Budgets</span>
        </NavLink>

        <NavLink
          to="/settings"
          className={({ isActive }) =>
            `flex flex-col items-center py-1 px-2 text-xs font-medium transition ${
              isActive ? 'text-teal-500 font-bold' : 'text-slate-500 dark:text-slate-400'
            }`
          }
        >
          <MoreHorizontal size={20} />
          <span className="mt-1">More</span>
        </NavLink>
      </div>
    </nav>
  );
}
