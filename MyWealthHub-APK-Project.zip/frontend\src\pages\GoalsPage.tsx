import React, { useState, useEffect } from 'react';
import { Target, PlusCircle, Sparkles, TrendingUp, Calendar, Trash2 } from 'lucide-react';
import { goalApi } from '../services/api';
import { Goal } from '../types';
import { GoalCard } from '../components/GoalCard';
import { Modal } from '../components/common/Modal';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { EmptyState } from '../components/common/EmptyState';
import { formatINR } from '../hooks/useCurrency';

export function GoalsPage() {
  const [goals, setGoals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form State
  const [name, setName] = useState('');
  const [type, setType] = useState('emergency_fund');
  const [targetAmount, setTargetAmount] = useState('');
  const [currentAmount, setCurrentAmount] = useState('');
  const [targetDate, setTargetDate] = useState('');
  const [monthlyContribution, setMonthlyContribution] = useState('');
  const [assumedReturnRate, setAssumedReturnRate] = useState('10');
  const [priority, setPriority] = useState('medium');
  const [saving, setSaving] = useState(false);

  const loadGoals = async () => {
    try {
      setLoading(true);
      const res = await goalApi.getGoals();
      setGoals(res || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadGoals();
  }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await goalApi.createGoal({
        name,
        type: type as any,
        targetAmount: parseFloat(targetAmount),
        currentAmount: currentAmount ? parseFloat(currentAmount) : 0,
        targetDate: targetDate || undefined,
        monthlyContribution: monthlyContribution ? parseFloat(monthlyContribution) : 0,
        assumedReturnRate: assumedReturnRate ? parseFloat(assumedReturnRate) : undefined,
        priority: priority as any,
      });
      setIsModalOpen(false);
      setName('');
      setTargetAmount('');
      setCurrentAmount('');
      setMonthlyContribution('');
      loadGoals();
    } catch (err) {
      alert('Failed to save financial goal.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!window.confirm('Delete this financial goal?')) return;
    await goalApi.deleteGoal(id);
    loadGoals();
  };

  const totalTargetPaise = goals.reduce((acc, g) => acc + (g.target_amount || 0), 0);
  const totalSavedPaise = goals.reduce((acc, g) => acc + (g.current_amount || 0), 0);
  const totalMonthlySipPaise = goals.reduce((acc, g) => acc + (g.monthly_contribution || 0), 0);

  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-5">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-xs font-bold text-teal-600 dark:text-teal-400 uppercase tracking-wider">
            <Target size={16} />
            <span>Aspiration Planning Engine</span>
          </div>
          <h2 className="text-xl md:text-2xl font-black text-slate-900 dark:text-white">
            {formatINR(totalSavedPaise)} / {formatINR(totalTargetPaise)}
          </h2>
          <p className="text-xs text-slate-500 font-mono">
            Active monthly SIP allocations: {formatINR(totalMonthlySipPaise)}/mo
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="px-5 py-3 rounded-xl bg-teal-500 hover:bg-teal-600 text-white font-bold text-sm flex items-center gap-2 shadow-md shadow-teal-500/20 transition self-start md:self-auto"
        >
          <PlusCircle size={18} />
          <span>New Financial Goal</span>
        </button>
      </div>

      {/* Goals Grid */}
      {loading ? (
        <LoadingSpinner message="Calculating goal milestone forecasts..." />
      ) : goals.length === 0 ? (
        <EmptyState
          icon={Target}
          title="No Goals Created Yet"
          description="Define emergency funds, children's education, vacation, or retirement targets with mathematical milestones."
          actionText="Create First Goal"
          onAction={() => setIsModalOpen(true)}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {goals.map((g) => (
            <div key={g.id} className="relative group">
              <GoalCard
                id={g.id}
                name={g.name}
                type={g.type}
                targetAmount={g.target_amount}
                currentAmount={g.current_amount}
                targetDate={g.target_date}
                monthlyContribution={g.monthly_contribution}
                priority={g.priority}
              />
              <button
                onClick={() => handleDelete(g.id)}
                className="absolute top-4 right-4 text-xs text-slate-400 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition p-1"
                title="Delete goal"
              >
                ✕
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Create Modal */}
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Define Financial Goal">
        <form onSubmit={handleCreate} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Goal Title</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Emergency Fund (6 Months Expenses)"
              className="input-field text-sm rounded-xl"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Goal Category</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value)}
                className="select-field text-sm rounded-xl"
              >
                <option value="emergency_fund">Emergency Fund</option>
                <option value="education">Children's Education</option>
                <option value="home">Home Purchase / Downpayment</option>
                <option value="retirement">Retirement Corpus</option>
                <option value="vacation">International Vacation</option>
                <option value="wealth">Wealth Creation</option>
                <option value="other">Other Life Goal</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Priority</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value)}
                className="select-field text-sm rounded-xl"
              >
                <option value="high">High Priority</option>
                <option value="medium">Medium Priority</option>
                <option value="low">Low Priority</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Target Amount (₹)</label>
              <input
                type="number"
                step="any"
                required
                value={targetAmount}
                onChange={(e) => setTargetAmount(e.target.value)}
                placeholder="e.g. 500000"
                className="input-field text-sm rounded-xl"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Current Saved (₹)</label>
              <input
                type="number"
                step="any"
                value={currentAmount}
                onChange={(e) => setCurrentAmount(e.target.value)}
                placeholder="e.g. 150000"
                className="input-field text-sm rounded-xl"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Target Date</label>
              <input
                type="date"
                value={targetDate}
                onChange={(e) => setTargetDate(e.target.value)}
                className="input-field text-sm rounded-xl"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Monthly Contribution (₹)</label>
              <input
                type="number"
                step="any"
                value={monthlyContribution}
                onChange={(e) => setMonthlyContribution(e.target.value)}
                placeholder="e.g. 20000"
                className="input-field text-sm rounded-xl"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={saving}
            className="w-full py-3 rounded-xl bg-teal-500 hover:bg-teal-600 text-white font-bold text-sm transition shadow-md disabled:opacity-50"
          >
            {saving ? 'Saving...' : 'Set Financial Goal'}
          </button>
        </form>
      </Modal>
    </div>
  );
}
