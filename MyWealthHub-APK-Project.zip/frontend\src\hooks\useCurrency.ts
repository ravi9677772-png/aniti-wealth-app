import { useMemo } from 'react';

/**
 * Indian Number formatting (Lakhs & Crores)
 * Expects value in paise (integer) or rupees
 */
export function formatINR(paiseOrRupees: number, isPaise: boolean = true): string {
  const rupees = isPaise ? paiseOrRupees / 100 : paiseOrRupees;
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(rupees);
}

export function formatINRWithDecimals(paiseOrRupees: number, isPaise: boolean = true): string {
  const rupees = isPaise ? paiseOrRupees / 100 : paiseOrRupees;
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(rupees);
}

export function useCurrency() {
  return useMemo(() => ({ formatINR, formatINRWithDecimals }), []);
}
