// ============================================================================
// My Wealth Hub — Auth Routes (Register, Login, Password, Me)
// ============================================================================

import { Router, Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { getDb, seedDefaultCategories, seedDefaultCategoryRules } from '../database';
import { generateToken } from '../middleware/auth';
import { AuthenticatedRequest, RegisterBody, LoginBody, ChangePasswordBody } from '../types';

const router = Router();

// Register new user (seeds default categories & rules)
router.post('/register', async (req: Request, res: Response): Promise<void> => {
  try {
    const { username, password, displayName } = req.body as RegisterBody;

    if (!username || !password) {
      res.status(400).json({ success: false, error: 'Username and password are required' });
      return;
    }

    if (password.length < 6) {
      res.status(400).json({ success: false, error: 'Password must be at least 6 characters' });
      return;
    }

    const db = getDb();
    const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
    if (existing) {
      res.status(409).json({ success: false, error: 'Username already taken' });
      return;
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const insertUser = db.prepare(
      'INSERT INTO users (username, password_hash, display_name) VALUES (?, ?, ?)'
    );
    const result = insertUser.run(username, passwordHash, displayName || username);
    const userId = Number(result.lastInsertRowid);

    // Auto seed categories & categorization rules for the newly registered user
    seedDefaultCategories(userId);
    seedDefaultCategoryRules(userId);

    // Create a default Primary Savings Account
    db.prepare(
      `INSERT INTO accounts (user_id, name, type, bank_name, balance, currency)
       VALUES (?, 'Primary Savings', 'savings', 'State Bank of India', 0, 'INR')`
    ).run(userId);

    const token = generateToken({ userId, username });

    res.status(201).json({
      success: true,
      data: {
        token,
        user: { id: userId, username, displayName: displayName || username },
      },
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Login
router.post('/login', async (req: Request, res: Response): Promise<void> => {
  try {
    const { username, password } = req.body as LoginBody;

    if (!username || !password) {
      res.status(400).json({ success: false, error: 'Username and password are required' });
      return;
    }

    const db = getDb();
    const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username) as any;

    if (!user) {
      res.status(401).json({ success: false, error: 'Invalid username or password' });
      return;
    }

    const match = await bcrypt.compare(password, user.password_hash);
    if (!match) {
      res.status(401).json({ success: false, error: 'Invalid username or password' });
      return;
    }

    const token = generateToken({ userId: user.id, username: user.username });

    res.json({
      success: true,
      data: {
        token,
        user: { id: user.id, username: user.username, displayName: user.display_name },
      },
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Get current user profile
router.get('/me', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user?.userId;
  if (!userId) {
    res.status(401).json({ success: false, error: 'Unauthorized' });
    return;
  }

  const db = getDb();
  const user = db.prepare('SELECT id, username, display_name, created_at FROM users WHERE id = ?').get(userId);

  if (!user) {
    res.status(404).json({ success: false, error: 'User not found' });
    return;
  }

  res.json({ success: true, data: user });
});

// Change password
router.post('/change-password', async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user?.userId;
    const { currentPassword, newPassword } = req.body as ChangePasswordBody;

    if (!userId || !currentPassword || !newPassword) {
      res.status(400).json({ success: false, error: 'Missing required fields' });
      return;
    }

    const db = getDb();
    const user = db.prepare('SELECT password_hash FROM users WHERE id = ?').get(userId) as any;
    if (!user) {
      res.status(404).json({ success: false, error: 'User not found' });
      return;
    }

    const match = await bcrypt.compare(currentPassword, user.password_hash);
    if (!match) {
      res.status(400).json({ success: false, error: 'Current password incorrect' });
      return;
    }

    const newHash = await bcrypt.hash(newPassword, 10);
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(newHash, userId);

    res.json({ success: true, message: 'Password updated successfully' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

export default router;
