import React from 'react';
import { ArrowUpRight, ArrowDownLeft, ArrowLeftRight, RotateCcw } from 'lucide-react';
import { formatINR } from '../hooks/useCurrency';

interface TransactionItemProps {
  id: number;
  type: string;
  amount: number; // in paise
  date: string;
  description: string | null;
  merchant?: string | null;
  categoryName?: string | null;
  categoryIcon?: string | null;
  accountName?: string | null;
  paymentMode?: string | null;
  onClick?: () => void;
  onDelete?: (e: React.MouseEvent) => void;
}

export function TransactionItem({
  type,
  amount,
  date,
  description,
  merchant,
  categoryName,
  categoryIcon,
  accountName,
  paymentMode,
  onClick,
  onDelete,
}: TransactionItemProps) {
  const isIncome = type === 'income';
  const isExpense = type === 'expense';
  const isTransfer = type === 'transfer';
  const isRefund = type === 'refund';

  const getTypeIcon = () => {
    if (isIncome) return <ArrowDownLeft size={16} className="text-emerald-500" />;
    if (isExpense) return <ArrowUpRight size={16} className="text-rose-500" />;
    if (isTransfer) return <ArrowLeftRight size={16} className="text-blue-500" />;
    return <RotateCcw size={16} className="text-teal-500" />;
  };

  const getAmountColor = () => {
    if (isIncome || isRefund) return 'text-emerald-600 dark:text-emerald-400';
    if (isExpense) return 'text-rose-600 dark:text-rose-400';
    return 'text-blue-600 dark:text-blue-400';
  };

  const prefix = isIncome || isRefund ? '+' : isExpense ? '-' : '';

  return (
    <div
      onClick={onClick}
      className="flex items-center justify-between p-3 md:p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800/80 hover:border-slate-300 dark:hover:border-slate-700 transition cursor-pointer"
    >
      <div className="flex items-center gap-3">
        {/* Category Icon */}
        <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-lg shrink-0">
          {categoryIcon || getTypeIcon()}
        </div>

        <div>
          <div className="font-semibold text-sm text-slate-800 dark:text-slate-100 leading-snug line-clamp-1">
            {merchant || description || 'Transaction'}
          </div>
          <div className="flex items-center gap-2 mt-0.5 text-xs text-slate-500 dark:text-slate-400">
            <span>{date ? date.slice(0, 10) : ''}</span>
            {categoryName && <span>• {categoryName}</span>}
            {accountName && <span className="hidden sm:inline">• {accountName}</span>}
            {paymentMode && <span className="uppercase text-[10px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800">{paymentMode}</span>}
          </div>
        </div>
      </div>

      <div className="text-right shrink-0 ml-3">
        <div className={`font-mono font-bold text-sm md:text-base ${getAmountColor()}`}>
          {prefix}{formatINR(amount)}
        </div>
        {onDelete && (
          <button
            onClick={onDelete}
            className="text-[11px] text-slate-400 hover:text-rose-500 transition mt-0.5"
          >
            Delete
          </button>
        )}
      </div>
    </div>
  );
}
