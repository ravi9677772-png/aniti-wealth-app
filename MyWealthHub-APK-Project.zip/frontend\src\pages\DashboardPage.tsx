import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Wallet,
  ArrowUpRight,
  ArrowDownLeft,
  PiggyBank,
  TrendingUp,
  ShieldAlert,
  Calendar,
  Clock,
  PlusCircle,
  UploadCloud,
  FileText,
  Building2,
} from 'lucide-react';
import { dashboardApi, transactionApi } from '../services/api';
import { DashboardData } from '../types';
import { StatCard } from '../components/StatCard';
import { TransactionItem } from '../components/TransactionItem';
import { BudgetProgressBar } from '../components/BudgetProgressBar';
import { IncomeExpenseChart } from '../components/Charts/IncomeExpenseChart';
import { CategoryPieChart } from '../components/Charts/CategoryPieChart';
import { NaturalLanguageInput } from '../components/NaturalLanguageInput';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { formatINR } from '../hooks/useCurrency';

export function DashboardPage() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  const fetchDashboard = async () => {
    try {
      setLoading(true);
      const res = await dashboardApi.getDashboard();
      setData(res);
    } catch (err: any) {
      setError(err?.response?.data?.error || 'Failed to fetch dashboard data.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboard();
  }, []);

  const handleNlParsed = (draft: any) => {
    // Navigate to Add Transaction page with draft state pre-filled
    navigate('/add-transaction', { state: { draft } });
  };

  if (loading) return <LoadingSpinner message="Calculating your financial position..." />;
  if (error || !data) {
    return (
      <div className="p-6 text-center text-rose-500 bg-rose-50 dark:bg-rose-950/30 rounded-2xl">
        {error || 'Unable to load dashboard.'}
      </div>
    );
  }

  const currentDateStr = new Date().toLocaleDateString('en-IN', {
    timeZone: 'Asia/Kolkata',
    month: 'long',
    year: 'numeric',
  });

  return (
    <div className="space-y-6">
      {/* Top Banner & Status */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-500/10 text-teal-600 dark:text-teal-400">
            <Calendar size={20} />
          </div>
          <div>
            <div className="text-xs text-slate-400 font-medium">Financial Overview For</div>
            <div className="text-base font-bold text-slate-900 dark:text-white">
              {currentDateStr} (IST)
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-slate-500 dark:text-slate-400">
          <Clock size={14} className="text-teal-500" />
          <span>Latest Sync: Today, Asia/Kolkata</span>
        </div>
      </div>

      {/* Natural Language Quick Input */}
      <NaturalLanguageInput onParsed={handleNlParsed} />

      {/* Primary KPI Grid (4 Cards) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-5">
        <StatCard
          title="Bank Balances"
          value={formatINR(data.totalBalance)}
          subtitle="Across active accounts"
          icon={Wallet}
          colorScheme="teal"
        />
        <StatCard
          title="Monthly Income"
          value={formatINR(data.monthlyIncome)}
          subtitle="Credits this month"
          icon={ArrowDownLeft}
          colorScheme="emerald"
        />
        <StatCard
          title="Monthly Expenses"
          value={formatINR(data.monthlyExpense)}
          subtitle="Debits this month"
          icon={ArrowUpRight}
          colorScheme="rose"
        />
        <StatCard
          title="Monthly Savings"
          value={formatINR(data.monthlyIncome - data.monthlyExpense)}
          subtitle={`${data.savingsRate}% Savings Rate`}
          icon={PiggyBank}
          colorScheme="blue"
        />
      </div>

      {/* Net Worth & Assets Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 text-white shadow-md flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs text-slate-400 font-semibold uppercase tracking-wider">
              <span>Estimated Net Worth</span>
              <TrendingUp size={16} className="text-teal-400" />
            </div>
            <div className="text-3xl font-black font-mono tracking-tight mt-2 text-teal-300">
              {formatINR(data.netWorth)}
            </div>
            <p className="text-xs text-slate-400 mt-1">Total Assets minus Total Liabilities</p>
          </div>

          <div className="pt-4 mt-4 border-t border-slate-700/60 grid grid-cols-2 gap-2 text-xs">
            <div>
              <span className="text-slate-400 block text-[11px]">Total Assets</span>
              <span className="font-mono font-bold text-emerald-400">{formatINR(data.totalAssets)}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[11px]">Total Debt</span>
              <span className="font-mono font-bold text-rose-400">{formatINR(data.totalLiabilities)}</span>
            </div>
          </div>
        </div>

        {/* Quick Actions Card */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="font-bold text-sm text-slate-800 dark:text-white mb-2">
              Management Actions
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Record new entries or import statement batches
            </p>
          </div>

          <div className="grid grid-cols-2 gap-2 mt-4">
            <button
              onClick={() => navigate('/add-transaction')}
              className="p-3 rounded-xl bg-teal-500/10 hover:bg-teal-500/20 text-teal-600 dark:text-teal-400 text-xs font-bold flex flex-col items-center gap-1.5 transition"
            >
              <PlusCircle size={20} />
              <span>Add Entry</span>
            </button>
            <button
              onClick={() => navigate('/import')}
              className="p-3 rounded-xl bg-blue-500/10 hover:bg-blue-500/20 text-blue-600 dark:text-blue-400 text-xs font-bold flex flex-col items-center gap-1.5 transition"
            >
              <UploadCloud size={20} />
              <span>Import CSV/XLS</span>
            </button>
          </div>
        </div>

        {/* Bank Connection Pill / Aggregator Notice */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-teal-600 dark:text-teal-400 uppercase tracking-wider">
              <Building2 size={16} />
              <span>Investments & Brokers</span>
            </div>
            <h4 className="text-sm font-bold text-slate-800 dark:text-white mt-1">
              Direct Portfolio Ingestion
            </h4>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
              Auto-sync mutual funds from CAMS/KFintech CAS statement and stock holdings from Zerodha, Groww, and Upstox.
            </p>
          </div>

          <button
            onClick={() => navigate('/investments')}
            className="text-xs font-bold text-teal-600 dark:text-teal-400 hover:underline text-left mt-3 flex items-center gap-1"
          >
            <span>Open Portfolio & Brokers Hub</span>
            <ArrowUpRight size={14} />
          </button>
        </div>
      </div>

      {/* Insurance Due Dates Alert Banner (If Any Upcoming) */}
      {data.upcomingInsurance && data.upcomingInsurance.length > 0 && (
        <div className="p-4 md:p-5 rounded-2xl bg-gradient-to-r from-amber-500/10 via-rose-500/10 to-amber-500/10 border border-amber-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500 text-white shrink-0">
              <ShieldAlert size={22} />
            </div>
            <div>
              <div className="text-xs font-bold text-amber-700 dark:text-amber-300 uppercase tracking-wider">
                Upcoming Insurance Premium Due Notice
              </div>
              <div className="text-sm font-bold text-slate-900 dark:text-white mt-0.5">
                {data.upcomingInsurance[0].policy_name} ({data.upcomingInsurance[0].provider})
              </div>
              <div className="text-xs font-mono text-slate-500 dark:text-slate-400">
                Premium: <span className="font-bold text-slate-900 dark:text-white">{formatINR(data.upcomingInsurance[0].premium_amount)}</span> • Due on: <span className="font-bold text-amber-600 dark:text-amber-400">{data.upcomingInsurance[0].next_due_date}</span>
              </div>
            </div>
          </div>

          <button
            onClick={() => navigate('/insurance')}
            className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs shadow-sm transition whitespace-nowrap self-start sm:self-auto"
          >
            View Insurance Calendar →
          </button>
        </div>
      )}

      {/* Interactive Charts (Two Column Grid) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-sm text-slate-800 dark:text-white">
              Income vs Expenses (Last 6 Months)
            </h3>
          </div>
          <IncomeExpenseChart data={data.incomeVsExpense} />
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-sm text-slate-800 dark:text-white">
              Expense Distribution (Current Month)
            </h3>
          </div>
          <CategoryPieChart data={data.expenseByCategory} />
        </div>
      </div>

      {/* Budgets & Upcoming Bills Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Budget Utilization */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-slate-800 dark:text-white">
              Budget Utilization
            </h3>
            <button
              onClick={() => navigate('/budgets')}
              className="text-xs font-bold text-teal-600 dark:text-teal-400 hover:underline"
            >
              View All
            </button>
          </div>

          {data.budgetSummary && data.budgetSummary.length > 0 ? (
            <div className="space-y-3">
              {data.budgetSummary.slice(0, 4).map((b) => (
                <BudgetProgressBar
                  key={b.budgetId}
                  categoryName={b.categoryName}
                  budgetAmount={b.budgetAmount}
                  spentAmount={b.spentAmount}
                  remainingAmount={b.remainingAmount}
                  utilizationPercent={b.utilizationPercent}
                />
              ))}
            </div>
          ) : (
            <div className="py-8 text-center text-xs text-slate-400">
              No active budgets for this month.
            </div>
          )}
        </div>

        {/* Upcoming Bills & EMIs */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-slate-800 dark:text-white">
              Upcoming Bills & EMIs
            </h3>
            <span className="text-xs text-slate-400">Next Scheduled</span>
          </div>

          {data.upcomingBills && data.upcomingBills.length > 0 ? (
            <div className="space-y-2">
              {data.upcomingBills.map((bill: any) => (
                <TransactionItem
                  key={bill.id}
                  id={bill.id}
                  type={bill.type}
                  amount={bill.amount}
                  date={bill.date}
                  description={bill.description}
                  merchant={bill.merchant}
                  categoryName={bill.category_name}
                  accountName={bill.account_name}
                  paymentMode={bill.payment_mode}
                />
              ))}
            </div>
          ) : (
            <div className="py-8 text-center text-xs text-slate-400">
              No upcoming scheduled bills detected.
            </div>
          )}
        </div>
      </div>

      {/* Recent Transactions List */}
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-bold text-base text-slate-800 dark:text-white">
              Recent Transactions
            </h3>
            <p className="text-xs text-slate-400">Latest entries from all accounts</p>
          </div>
          <button
            onClick={() => navigate('/transactions')}
            className="text-xs font-bold text-teal-600 dark:text-teal-400 hover:underline"
          >
            Full Register →
          </button>
        </div>

        {data.recentTransactions && data.recentTransactions.length > 0 ? (
          <div className="space-y-2">
            {data.recentTransactions.map((tx: any) => (
              <TransactionItem
                key={tx.id}
                id={tx.id}
                type={tx.type}
                amount={tx.amount}
                date={tx.date}
                description={tx.description}
                merchant={tx.merchant}
                categoryName={tx.category_name}
                categoryIcon={tx.category_icon}
                accountName={tx.account_name}
                paymentMode={tx.payment_mode}
              />
            ))}
          </div>
        ) : (
          <div className="py-8 text-center text-xs text-slate-400">
            No transactions recorded yet.
          </div>
        )}
      </div>
    </div>
  );
}
