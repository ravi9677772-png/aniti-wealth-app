import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Search,
  Filter,
  PlusCircle,
  Download,
  Calendar,
  X,
  Trash2,
} from 'lucide-react';
import { transactionApi, accountApi, categoryApi } from '../services/api';
import { Transaction, Account, Category } from '../types';
import { TransactionItem } from '../components/TransactionItem';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { EmptyState } from '../components/common/EmptyState';
import { Receipt } from 'lucide-react';

export function TransactionsPage() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters state
  const [search, setSearch] = useState('');
  const [type, setType] = useState<string>('');
  const [accountId, setAccountId] = useState<string>('');
  const [categoryId, setCategoryId] = useState<string>('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [sortBy, setSortBy] = useState('date');
  const [sortOrder, setSortOrder] = useState<'ASC' | 'DESC'>('DESC');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  const navigate = useNavigate();

  const loadData = async () => {
    try {
      setLoading(true);
      const [txRes, accRes, catRes] = await Promise.all([
        transactionApi.getTransactions({
          search: search || undefined,
          type: (type as any) || undefined,
          accountId: accountId ? Number(accountId) : undefined,
          categoryId: categoryId ? Number(categoryId) : undefined,
          startDate: startDate || undefined,
          endDate: endDate || undefined,
          sortBy,
          sortOrder,
          page,
          limit: 30,
        }),
        accountApi.getAccounts(),
        categoryApi.getCategories(),
      ]);

      setTransactions(txRes.data || []);
      setTotalPages(txRes.pagination?.totalPages || 1);
      setAccounts(accRes || []);
      setCategories(catRes || []);
    } catch (err) {
      console.error('Error fetching transactions:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [type, accountId, categoryId, startDate, endDate, sortBy, sortOrder, page]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    loadData();
  };

  const handleDelete = async (e: React.MouseEvent, id: number) => {
    e.stopPropagation();
    if (!window.confirm('Delete this transaction and reverse its balance impact?')) return;
    try {
      await transactionApi.deleteTransaction(id);
      loadData();
    } catch (err: any) {
      alert(err?.response?.data?.error || 'Failed to delete transaction.');
    }
  };

  const clearFilters = () => {
    setSearch('');
    setType('');
    setAccountId('');
    setCategoryId('');
    setStartDate('');
    setEndDate('');
    setPage(1);
  };

  const hasActiveFilters = !!(search || type || accountId || categoryId || startDate || endDate);

  return (
    <div className="space-y-5">
      {/* Search & Action Bar */}
      <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
        <form onSubmit={handleSearchSubmit} className="flex-1 relative">
          <Search size={18} className="absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search transactions, merchants, notes..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500 shadow-sm"
          />
        </form>

        <div className="flex items-center gap-2">
          <button
            onClick={() => navigate('/add-transaction')}
            className="px-4 py-2.5 rounded-xl bg-teal-500 hover:bg-teal-600 text-white font-bold text-xs md:text-sm flex items-center gap-1.5 shadow-md shadow-teal-500/20 transition"
          >
            <PlusCircle size={16} />
            <span>Add Transaction</span>
          </button>
        </div>
      </div>

      {/* Filter Row */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-600 dark:text-slate-300 uppercase tracking-wider">
            <Filter size={14} className="text-teal-500" />
            <span>Filter Register</span>
          </div>

          {hasActiveFilters && (
            <button
              onClick={clearFilters}
              className="text-xs text-rose-500 hover:underline flex items-center gap-1"
            >
              <X size={14} />
              <span>Reset Filters</span>
            </button>
          )}
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2.5">
          {/* Type Filter */}
          <select
            value={type}
            onChange={(e) => {
              setType(e.target.value);
              setPage(1);
            }}
            className="select-field text-xs py-2 px-3 rounded-lg bg-slate-50 dark:bg-slate-800"
          >
            <option value="">All Types</option>
            <option value="income">Income</option>
            <option value="expense">Expense</option>
            <option value="transfer">Transfer</option>
            <option value="refund">Refund</option>
          </select>

          {/* Account Filter */}
          <select
            value={accountId}
            onChange={(e) => {
              setAccountId(e.target.value);
              setPage(1);
            }}
            className="select-field text-xs py-2 px-3 rounded-lg bg-slate-50 dark:bg-slate-800"
          >
            <option value="">All Accounts</option>
            {accounts.map((a) => (
              <option key={a.id} value={a.id}>
                {a.name}
              </option>
            ))}
          </select>

          {/* Category Filter */}
          <select
            value={categoryId}
            onChange={(e) => {
              setCategoryId(e.target.value);
              setPage(1);
            }}
            className="select-field text-xs py-2 px-3 rounded-lg bg-slate-50 dark:bg-slate-800"
          >
            <option value="">All Categories</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>

          {/* Start Date */}
          <input
            type="date"
            value={startDate}
            onChange={(e) => {
              setStartDate(e.target.value);
              setPage(1);
            }}
            className="input-field text-xs py-2 px-3 rounded-lg bg-slate-50 dark:bg-slate-800"
            title="Start date"
          />

          {/* End Date */}
          <input
            type="date"
            value={endDate}
            onChange={(e) => {
              setEndDate(e.target.value);
              setPage(1);
            }}
            className="input-field text-xs py-2 px-3 rounded-lg bg-slate-50 dark:bg-slate-800"
            title="End date"
          />
        </div>
      </div>

      {/* Transactions List */}
      {loading ? (
        <LoadingSpinner message="Searching transactions..." />
      ) : transactions.length === 0 ? (
        <EmptyState
          icon={Receipt}
          title="No Transactions Found"
          description={
            hasActiveFilters
              ? 'Try widening or clearing your filters.'
              : 'Add your first transaction manually or import a bank statement.'
          }
          actionText="Add Transaction"
          onAction={() => navigate('/add-transaction')}
        />
      ) : (
        <div className="space-y-2">
          {transactions.map((tx: any) => (
            <TransactionItem
              key={tx.id}
              id={tx.id}
              type={tx.type}
              amount={tx.amount}
              date={tx.date}
              description={tx.description}
              merchant={tx.merchant}
              categoryName={tx.category_name}
              categoryIcon={tx.category_icon}
              accountName={tx.account_name}
              paymentMode={tx.payment_mode}
              onClick={() => navigate('/add-transaction', { state: { transaction: tx } })}
              onDelete={(e) => handleDelete(e, tx.id)}
            />
          ))}

          {/* Pagination Controls */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between pt-4 border-t border-slate-200 dark:border-slate-800 text-xs">
              <button
                disabled={page <= 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                className="px-3 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 disabled:opacity-40"
              >
                Previous
              </button>
              <span className="text-slate-500 font-mono">
                Page {page} of {totalPages}
              </span>
              <button
                disabled={page >= totalPages}
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                className="px-3 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 disabled:opacity-40"
              >
                Next
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
