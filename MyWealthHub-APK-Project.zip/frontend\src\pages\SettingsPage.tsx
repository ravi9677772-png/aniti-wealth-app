import React, { useState, useEffect } from 'react';
import {
  Settings,
  Building2,
  PlusCircle,
  Tag,
  ShieldCheck,
  Moon,
  Sun,
  Database,
  Lock,
  User,
  RefreshCw,
  LogOut,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { accountApi, categoryApi } from '../services/api';
import { Account, Category } from '../types';
import { Modal } from '../components/common/Modal';
import { formatINR } from '../hooks/useCurrency';

export function SettingsPage() {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();

  const [accounts, setAccounts] = useState<Account[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  // Add Account Modal
  const [isAccModalOpen, setIsAccModalOpen] = useState(false);
  const [accName, setAccName] = useState('');
  const [accType, setAccType] = useState('savings');
  const [accBank, setAccBank] = useState('');
  const [accNumberMasked, setAccNumberMasked] = useState('');
  const [accBalance, setAccBalance] = useState('');

  // Add Category Modal
  const [isCatModalOpen, setIsCatModalOpen] = useState(false);
  const [catName, setCatName] = useState('');
  const [catType, setCatType] = useState<'income' | 'expense'>('expense');
  const [catIcon, setCatIcon] = useState('📁');

  const loadData = async () => {
    try {
      setLoading(true);
      const [aRes, cRes] = await Promise.all([
        accountApi.getAccounts(),
        categoryApi.getCategories(),
      ]);
      setAccounts(aRes || []);
      setCategories(cRes || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleCreateAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await accountApi.createAccount({
        name: accName,
        type: accType as any,
        bankName: accBank,
        accountNumberMasked: accNumberMasked,
        balance: accBalance ? parseFloat(accBalance) : 0,
      });
      setIsAccModalOpen(false);
      setAccName('');
      setAccBalance('');
      loadData();
    } catch (err) {
      alert('Failed to add bank account.');
    }
  };

  const handleCreateCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await categoryApi.createCategory({
        name: catName,
        type: catType,
        icon: catIcon,
      });
      setIsCatModalOpen(false);
      setCatName('');
      loadData();
    } catch (err) {
      alert('Failed to add category.');
    }
  };

  const handleSyncAccount = async (id: number) => {
    try {
      await accountApi.syncAccount(id);
      alert('Account timestamp synchronized.');
      loadData();
    } catch (err) {
      alert('Failed to sync account.');
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Profile Card */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-teal-500/10 text-teal-600 dark:text-teal-400 flex items-center justify-center font-bold text-xl">
            {user?.displayName ? user.displayName.charAt(0).toUpperCase() : 'U'}
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-800 dark:text-white">
              {user?.displayName || user?.username}
            </h2>
            <p className="text-xs text-slate-400 font-mono">@{user?.username} • Master Profile</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={toggleTheme}
            className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-2"
          >
            {theme === 'dark' ? <Sun size={16} className="text-amber-400" /> : <Moon size={16} />}
            <span>{theme === 'dark' ? 'Light Theme' : 'Dark Theme'}</span>
          </button>
          <button
            onClick={logout}
            className="px-4 py-2 rounded-xl bg-rose-50 text-rose-600 dark:bg-rose-950/40 dark:text-rose-400 text-xs font-bold flex items-center gap-1.5"
          >
            <LogOut size={16} />
            <span>Sign Out</span>
          </button>
        </div>
      </div>

      {/* Accounts Management */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-bold text-base text-slate-800 dark:text-white flex items-center gap-2">
              <Building2 size={18} className="text-teal-500" />
              <span>Registered Accounts & Wallets</span>
            </h3>
            <p className="text-xs text-slate-400">All balances are tracked in Indian Rupees (INR)</p>
          </div>
          <button
            onClick={() => setIsAccModalOpen(true)}
            className="px-3.5 py-2 rounded-xl bg-teal-500 text-white font-bold text-xs flex items-center gap-1.5"
          >
            <PlusCircle size={14} />
            <span>Add Account</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {accounts.map((acc) => (
            <div
              key={acc.id}
              className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between"
            >
              <div>
                <div className="font-bold text-sm text-slate-800 dark:text-white">{acc.name}</div>
                <div className="text-xs text-slate-400">
                  {acc.bank_name || acc.type} {acc.account_number_masked ? `• ${acc.account_number_masked}` : ''}
                </div>
                <div className="text-xs font-mono text-slate-400 mt-1">
                  Last synced: {acc.last_synced_at ? acc.last_synced_at.slice(0, 16) : 'Manual'}
                </div>
              </div>

              <div className="text-right">
                <div className="font-mono font-bold text-slate-900 dark:text-white text-base">
                  {formatINR(acc.balance)}
                </div>
                <button
                  onClick={() => handleSyncAccount(acc.id)}
                  className="text-[11px] text-teal-600 dark:text-teal-400 hover:underline flex items-center gap-1 ml-auto mt-1"
                >
                  <RefreshCw size={12} />
                  <span>Sync</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Security & Privacy Commitment */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-center gap-2 text-sm font-bold text-teal-600 dark:text-teal-400">
          <ShieldCheck size={20} />
          <span>Security & Privacy Architecture</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 space-y-1.5">
            <span className="font-bold text-slate-800 dark:text-white block">
              Zero Secret Exposure Policy
            </span>
            <p>
              This application <strong>NEVER</strong> collects, stores, or requests internet banking passwords, UPI PINs, debit card PINs, OTPs, or authentication secrets. All integrations are read-only.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 space-y-1.5">
            <span className="font-bold text-slate-800 dark:text-white block">
              Private Persistent Storage
            </span>
            <p>
              Your database is stored locally in <code>wealth-hub.db</code> (SQLite WAL mode). No financial transactions are dispatched to external AI third-parties.
            </p>
          </div>
        </div>
      </div>

      {/* Add Account Modal */}
      <Modal isOpen={isAccModalOpen} onClose={() => setIsAccModalOpen(false)} title="Register Bank Account">
        <form onSubmit={handleCreateAccount} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Account Name</label>
            <input
              type="text"
              required
              value={accName}
              onChange={(e) => setAccName(e.target.value)}
              placeholder="e.g. HDFC Salary Account"
              className="input-field text-sm rounded-xl"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Account Type</label>
              <select
                value={accType}
                onChange={(e) => setAccType(e.target.value)}
                className="select-field text-sm rounded-xl"
              >
                <option value="savings">Savings Account</option>
                <option value="current">Current Account</option>
                <option value="credit_card">Credit Card</option>
                <option value="cash">Cash Wallet</option>
                <option value="wallet">Digital Wallet</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Bank Name</label>
              <input
                type="text"
                value={accBank}
                onChange={(e) => setAccBank(e.target.value)}
                placeholder="e.g. HDFC Bank, SBI"
                className="input-field text-sm rounded-xl"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Last 4 Digits (Optional)</label>
              <input
                type="text"
                value={accNumberMasked}
                onChange={(e) => setAccNumberMasked(e.target.value)}
                placeholder="e.g. XXXX 4819"
                className="input-field text-sm rounded-xl"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Initial Balance (₹)</label>
              <input
                type="number"
                step="any"
                value={accBalance}
                onChange={(e) => setAccBalance(e.target.value)}
                placeholder="e.g. 50000"
                className="input-field text-sm rounded-xl"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-teal-500 hover:bg-teal-600 text-white font-bold text-sm transition shadow-md"
          >
            Save Account
          </button>
        </form>
      </Modal>
    </div>
  );
}
