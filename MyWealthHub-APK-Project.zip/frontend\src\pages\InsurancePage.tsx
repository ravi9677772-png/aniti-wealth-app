import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  AlertTriangle,
  Calendar,
  PlusCircle,
  Clock,
  HeartPulse,
  Car,
  CheckCircle2,
  Trash2,
  Building2,
  Check,
} from 'lucide-react';
import { insuranceApi, accountApi } from '../services/api';
import { Modal } from '../components/common/Modal';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { EmptyState } from '../components/common/EmptyState';
import { formatINR } from '../hooks/useCurrency';

export function InsurancePage() {
  const [policies, setPolicies] = useState<any[]>([]);
  const [summary, setSummary] = useState<any | null>(null);
  const [accounts, setAccounts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [policyName, setPolicyName] = useState('');
  const [policyNumber, setPolicyNumber] = useState('');
  const [provider, setProvider] = useState('');
  const [policyType, setPolicyType] = useState('term_life');
  const [sumInsured, setSumInsured] = useState('');
  const [premiumAmount, setPremiumAmount] = useState('');
  const [paymentFrequency, setPaymentFrequency] = useState('annual');
  const [nextDueDate, setNextDueDate] = useState('');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);

  // Mark Paid Modal
  const [payingPolicy, setPayingPolicy] = useState<any | null>(null);
  const [payAccountId, setPayAccountId] = useState('');

  const loadData = async () => {
    try {
      setLoading(true);
      const [pRes, sRes, accRes] = await Promise.all([
        insuranceApi.getPolicies(),
        insuranceApi.getSummary(),
        accountApi.getAccounts(),
      ]);
      setPolicies(pRes || []);
      setSummary(sRes || null);
      setAccounts(accRes || []);
      if (accRes && accRes.length > 0) setPayAccountId(String(accRes[0].id));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!policyName || !provider || !nextDueDate) {
      alert('Please fill in required fields.');
      return;
    }

    setSaving(true);
    try {
      await insuranceApi.createPolicy({
        policyName,
        policyNumber,
        provider,
        policyType,
        sumInsured: parseFloat(sumInsured || '0'),
        premiumAmount: parseFloat(premiumAmount || '0'),
        paymentFrequency,
        nextDueDate,
        notes,
      });
      setIsModalOpen(false);
      setPolicyName('');
      setPolicyNumber('');
      setProvider('');
      setSumInsured('');
      setPremiumAmount('');
      setNextDueDate('');
      loadData();
    } catch (err) {
      alert('Failed to save policy.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!window.confirm('Remove this insurance policy?')) return;
    await insuranceApi.deletePolicy(id);
    loadData();
  };

  const handleConfirmPay = async () => {
    if (!payingPolicy) return;
    try {
      await insuranceApi.markPaid(payingPolicy.id, payAccountId ? Number(payAccountId) : undefined);
      setPayingPolicy(null);
      loadData();
    } catch (err) {
      alert('Failed to register payment.');
    }
  };

  const getTypeIcon = (type: string) => {
    if (type === 'term_life') return <ShieldCheck className="text-teal-500" size={20} />;
    if (type === 'health' || type === 'critical_illness') return <HeartPulse className="text-rose-500" size={20} />;
    if (type === 'vehicle') return <Car className="text-blue-500" size={20} />;
    return <Building2 className="text-amber-500" size={20} />;
  };

  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="p-6 rounded-3xl bg-slate-900 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6 border border-slate-800">
        <div className="space-y-1">
          <div className="text-xs text-teal-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
            <ShieldCheck size={16} />
            <span>Family Financial Protection & Insurance Desk</span>
          </div>
          <h2 className="text-xl md:text-2xl font-black text-white">
            Total Annual Premium Burden: {summary ? formatINR(summary.totalAnnualPremium) : '₹0'}
          </h2>
          <p className="text-xs text-slate-400 font-mono">
            Monthly premium equivalent: {summary ? formatINR(summary.monthlyBurden) : '₹0'}/mo
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="px-5 py-3 rounded-xl bg-teal-500 hover:bg-teal-600 text-white font-bold text-sm flex items-center gap-2 shadow-md shadow-teal-500/20 transition self-start md:self-auto"
        >
          <PlusCircle size={18} />
          <span>Add Insurance Policy</span>
        </button>
      </div>

      {/* Coverage Tiles */}
      {summary && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm">
            <span className="text-xs text-slate-400 font-medium">Life Cover (Term)</span>
            <div className="text-lg md:text-xl font-bold font-mono text-teal-500 mt-1">
              {formatINR(summary.termLifeCover)}
            </div>
            <span className="text-[10px] text-slate-400">Sum Assured</span>
          </div>
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm">
            <span className="text-xs text-slate-400 font-medium">Health & Critical Cover</span>
            <div className="text-lg md:text-xl font-bold font-mono text-rose-500 mt-1">
              {formatINR(summary.healthCover)}
            </div>
            <span className="text-[10px] text-slate-400">Family Floater</span>
          </div>
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm">
            <span className="text-xs text-slate-400 font-medium">Motor Vehicles Cover</span>
            <div className="text-lg md:text-xl font-bold font-mono text-blue-500 mt-1">
              {formatINR(summary.vehicleCover)}
            </div>
            <span className="text-[10px] text-slate-400">IDV Value</span>
          </div>
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm">
            <span className="text-xs text-slate-400 font-medium">Active Policies</span>
            <div className="text-lg md:text-xl font-bold font-mono text-slate-800 dark:text-slate-100 mt-1">
              {summary.totalPolicies} policies
            </div>
            <span className="text-[10px] text-emerald-500 font-bold">100% Active</span>
          </div>
        </div>
      )}

      {/* Policies List with Renewal Status */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-base text-slate-800 dark:text-white flex items-center gap-2">
            <Calendar size={18} className="text-teal-500" />
            <span>Upcoming Policy Due Dates & Renewal Calendar</span>
          </h3>
          <span className="text-xs text-slate-400 font-mono">Sorted by earliest due</span>
        </div>

        {loading ? (
          <LoadingSpinner message="Loading insurance portfolio..." />
        ) : policies.length === 0 ? (
          <EmptyState
            icon={ShieldCheck}
            title="No Insurance Policies Tracked"
            description="Add your Life, Health, and Motor insurance policies to track renewal due dates and prevent lapses."
            actionText="Add Policy"
            onAction={() => setIsModalOpen(true)}
          />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {policies.map((p) => {
              const isUrgent = p.days_until_due <= 30 && p.days_until_due >= 0;
              const isOverdue = p.days_until_due < 0;

              return (
                <div
                  key={p.id}
                  className={`p-5 rounded-2xl bg-white dark:bg-slate-900 border flex flex-col justify-between space-y-4 shadow-sm hover:shadow-md transition ${
                    isOverdue
                      ? 'border-rose-400 dark:border-rose-800'
                      : isUrgent
                      ? 'border-amber-400 dark:border-amber-800'
                      : 'border-slate-200/80 dark:border-slate-800'
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <div className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 shrink-0">
                          {getTypeIcon(p.policy_type)}
                        </div>
                        <div>
                          <h4 className="font-bold text-sm text-slate-900 dark:text-white leading-tight">
                            {p.policy_name}
                          </h4>
                          <p className="text-xs text-slate-400 mt-0.5">
                            {p.provider} {p.policy_number ? `• ${p.policy_number}` : ''}
                          </p>
                        </div>
                      </div>

                      <button
                        onClick={() => handleDelete(p.id)}
                        className="text-slate-400 hover:text-rose-500 transition p-1"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>

                    {/* Due Date Badge */}
                    <div className="mt-4 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-700/60 flex items-center justify-between">
                      <div>
                        <span className="text-[10px] text-slate-400 uppercase font-mono block">Next Due Date</span>
                        <span className="text-xs font-bold font-mono text-slate-800 dark:text-slate-100">
                          {p.next_due_date}
                        </span>
                      </div>

                      <div className="text-right">
                        {isOverdue ? (
                          <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300">
                            Overdue ({Math.abs(p.days_until_due)}d)
                          </span>
                        ) : isUrgent ? (
                          <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300">
                            Due in {p.days_until_due} days
                          </span>
                        ) : (
                          <span className="text-[10px] font-bold font-mono text-slate-500">
                            in {p.days_until_due} days
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3 pt-2">
                    <div className="flex justify-between items-baseline text-xs font-mono">
                      <span className="text-slate-400">Premium ({p.payment_frequency})</span>
                      <span className="text-base font-bold text-slate-900 dark:text-white">
                        {formatINR(p.premium_amount)}
                      </span>
                    </div>

                    <div className="flex justify-between items-baseline text-xs font-mono">
                      <span className="text-slate-400">Sum Insured</span>
                      <span className="font-semibold text-teal-600 dark:text-teal-400">
                        {formatINR(p.sum_insured)}
                      </span>
                    </div>

                    <button
                      onClick={() => setPayingPolicy(p)}
                      className="w-full py-2 px-3 rounded-xl bg-teal-500/10 hover:bg-teal-500/20 text-teal-600 dark:text-teal-400 text-xs font-bold transition flex items-center justify-center gap-1.5"
                    >
                      <CheckCircle2 size={15} />
                      <span>Mark Premium Paid</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Add Policy Modal */}
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Add Insurance Policy">
        <form onSubmit={handleCreate} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Policy Name *</label>
            <input
              type="text"
              required
              value={policyName}
              onChange={(e) => setPolicyName(e.target.value)}
              placeholder="e.g. HDFC Life Click 2 Protect Term Plan"
              className="input-field text-sm rounded-xl"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Policy Type *</label>
              <select
                value={policyType}
                onChange={(e) => setPolicyType(e.target.value)}
                className="select-field text-sm rounded-xl"
              >
                <option value="term_life">Term Life Insurance</option>
                <option value="health">Health Insurance Floater</option>
                <option value="critical_illness">Critical Illness Cover</option>
                <option value="vehicle">Motor / Vehicle Insurance</option>
                <option value="home">Home Insurance</option>
                <option value="other">Other Insurance</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Insurance Provider *</label>
              <input
                type="text"
                required
                value={provider}
                onChange={(e) => setProvider(e.target.value)}
                placeholder="e.g. HDFC Life, Care Health"
                className="input-field text-sm rounded-xl"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Policy Number</label>
              <input
                type="text"
                value={policyNumber}
                onChange={(e) => setPolicyNumber(e.target.value)}
                placeholder="e.g. POL-882190"
                className="input-field text-sm rounded-xl"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Frequency</label>
              <select
                value={paymentFrequency}
                onChange={(e) => setPaymentFrequency(e.target.value)}
                className="select-field text-sm rounded-xl"
              >
                <option value="annual">Annual (Once a year)</option>
                <option value="semi_annual">Semi-Annual (Half yearly)</option>
                <option value="quarterly">Quarterly</option>
                <option value="monthly">Monthly</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Sum Insured (₹)</label>
              <input
                type="number"
                step="any"
                value={sumInsured}
                onChange={(e) => setSumInsured(e.target.value)}
                placeholder="e.g. 10000000 (1 Cr)"
                className="input-field text-sm rounded-xl"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Premium Amount (₹)</label>
              <input
                type="number"
                step="any"
                value={premiumAmount}
                onChange={(e) => setPremiumAmount(e.target.value)}
                placeholder="e.g. 18500"
                className="input-field text-sm rounded-xl"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Next Premium Due Date *</label>
            <input
              type="date"
              required
              value={nextDueDate}
              onChange={(e) => setNextDueDate(e.target.value)}
              className="input-field text-sm rounded-xl"
            />
          </div>

          <button
            type="submit"
            disabled={saving}
            className="w-full py-3 rounded-xl bg-teal-500 hover:bg-teal-600 text-white font-bold text-sm transition shadow-md disabled:opacity-50"
          >
            {saving ? 'Saving...' : 'Save Policy'}
          </button>
        </form>
      </Modal>

      {/* Mark Paid Confirmation Modal */}
      <Modal isOpen={!!payingPolicy} onClose={() => setPayingPolicy(null)} title="Confirm Premium Payment">
        {payingPolicy && (
          <div className="space-y-4">
            <p className="text-xs text-slate-600 dark:text-slate-300">
              Confirm paying premium of <strong>{formatINR(payingPolicy.premium_amount)}</strong> for{' '}
              <strong>{payingPolicy.policy_name}</strong>?
            </p>
            <p className="text-xs text-slate-400">
              This will automatically advance your policy's next due date by 1 cycle and log an expense transaction in your selected bank account.
            </p>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Payment Account</label>
              <select
                value={payAccountId}
                onChange={(e) => setPayAccountId(e.target.value)}
                className="select-field text-sm rounded-xl"
              >
                <option value="">Do not log bank transaction</option>
                {accounts.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.name} ({formatINR(a.balance)})
                  </option>
                ))}
              </select>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setPayingPolicy(null)}
                className="py-2.5 px-4 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-600 dark:text-slate-300"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmPay}
                className="flex-1 py-2.5 rounded-xl bg-teal-500 hover:bg-teal-600 text-white font-bold text-xs shadow-md transition"
              >
                Confirm Payment & Advance Due Date
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
