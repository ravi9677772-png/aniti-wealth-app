// ============================================================================
// My Wealth Hub — Reports & Analytics Routes
// ============================================================================

import { Router, Response } from 'express';
import { AuthenticatedRequest } from '../types';
import { getReportData } from '../services/analyticsService';

const router = Router();

router.get('/', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const { startDate, endDate } = req.query as { startDate?: string; endDate?: string };

  try {
    const data = getReportData(userId, startDate, endDate);
    res.json({ success: true, data });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

export default router;
