// ============================================================================
// My Wealth Hub — Goals Routes
// ============================================================================

import { Router, Response } from 'express';
import { getDb } from '../database';
import { AuthenticatedRequest, rupeesToPaise, paiseToRupees } from '../types';

const router = Router();

// List all goals
router.get('/', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const db = getDb();
  const goals = db
    .prepare('SELECT * FROM goals WHERE user_id = ? AND is_active = 1 ORDER BY target_date ASC')
    .all(userId) as any[];

  // Calculate progress and remaining for each goal
  const enriched = goals.map((g) => {
    const remaining = Math.max(0, g.target_amount - g.current_amount);
    const progressPercent = g.target_amount > 0 ? Math.min(100, Math.round((g.current_amount / g.target_amount) * 100)) : 0;

    // Months remaining to target date
    let monthsRemaining = 0;
    if (g.target_date) {
      const now = new Date();
      const target = new Date(g.target_date);
      monthsRemaining = Math.max(1, (target.getFullYear() - now.getFullYear()) * 12 + (target.getMonth() - now.getMonth()));
    }

    // Required monthly savings without interest
    const simpleRequiredMonthly = monthsRemaining > 0 ? Math.round(remaining / monthsRemaining) : remaining;

    return {
      ...g,
      remaining_amount: remaining,
      progress_percent: progressPercent,
      months_remaining: monthsRemaining,
      simple_required_monthly: simpleRequiredMonthly,
    };
  });

  res.json({ success: true, data: enriched });
});

// Create goal
router.post('/', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const {
    name,
    type,
    targetAmount, // rupees
    currentAmount = 0, // rupees
    targetDate,
    monthlyContribution = 0, // rupees
    assumedReturnRate,
    priority = 'medium',
    notes,
  } = req.body;

  if (!name || !type || targetAmount === undefined) {
    res.status(400).json({ success: false, error: 'Name, type, and target amount are required' });
    return;
  }

  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO goals (
      user_id, name, type, target_amount, current_amount, target_date,
      monthly_contribution, assumed_return_rate, priority, notes
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const result = stmt.run(
    userId,
    name,
    type,
    rupeesToPaise(Number(targetAmount)),
    rupeesToPaise(Number(currentAmount)),
    targetDate || null,
    rupeesToPaise(Number(monthlyContribution)),
    assumedReturnRate || null,
    priority,
    notes || null
  );

  const created = db.prepare('SELECT * FROM goals WHERE id = ?').get(result.lastInsertRowid);
  res.status(201).json({ success: true, data: created });
});

// Update goal
router.put('/:id', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const db = getDb();
  const existing = db.prepare('SELECT * FROM goals WHERE id = ? AND user_id = ?').get(req.params.id, userId) as any;

  if (!existing) {
    res.status(404).json({ success: false, error: 'Goal not found' });
    return;
  }

  const {
    name = existing.name,
    type = existing.type,
    targetAmount,
    currentAmount,
    targetDate = existing.target_date,
    monthlyContribution,
    assumedReturnRate = existing.assumed_return_rate,
    priority = existing.priority,
    notes = existing.notes,
    isActive = existing.is_active,
  } = req.body;

  const tAmt = targetAmount !== undefined ? rupeesToPaise(Number(targetAmount)) : existing.target_amount;
  const cAmt = currentAmount !== undefined ? rupeesToPaise(Number(currentAmount)) : existing.current_amount;
  const mContr = monthlyContribution !== undefined ? rupeesToPaise(Number(monthlyContribution)) : existing.monthly_contribution;

  db.prepare(`
    UPDATE goals
    SET name = ?, type = ?, target_amount = ?, current_amount = ?, target_date = ?,
        monthly_contribution = ?, assumed_return_rate = ?, priority = ?, notes = ?,
        is_active = ?, updated_at = CURRENT_TIMESTAMP
    WHERE id = ? AND user_id = ?
  `).run(
    name,
    type,
    tAmt,
    cAmt,
    targetDate,
    mContr,
    assumedReturnRate,
    priority,
    notes,
    isActive ? 1 : 0,
    req.params.id,
    userId
  );

  const updated = db.prepare('SELECT * FROM goals WHERE id = ?').get(req.params.id);
  res.json({ success: true, data: updated });
});

// Delete goal
router.delete('/:id', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const db = getDb();
  db.prepare('DELETE FROM goals WHERE id = ? AND user_id = ?').run(req.params.id, userId);
  res.json({ success: true, message: 'Goal deleted.' });
});

export default router;
