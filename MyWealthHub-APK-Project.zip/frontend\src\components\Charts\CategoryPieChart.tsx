import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { formatINR } from '../../hooks/useCurrency';

interface CategoryPieChartProps {
  data: { categoryName: string; amount: number; percentage: number }[];
}

const COLORS = [
  '#14b8a6', '#f43f5e', '#3b82f6', '#f59e0b', '#8b5cf6',
  '#06b6d4', '#10b981', '#ec4899', '#6366f1', '#84cc16',
];

export function CategoryPieChart({ data }: CategoryPieChartProps) {
  if (!data || data.length === 0) {
    return (
      <div className="h-64 flex items-center justify-center text-slate-400 text-sm">
        No category expenses recorded for this period.
      </div>
    );
  }

  const chartData = data.slice(0, 7).map((d) => ({
    name: d.categoryName,
    value: d.amount / 100, // to rupees
  }));

  return (
    <div className="w-full h-72">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={chartData}
            cx="50%"
            cy="50%"
            innerRadius={55}
            outerRadius={85}
            paddingAngle={3}
            dataKey="value"
          >
            {chartData.map((_, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip
            formatter={(value: any) => [`₹${Number(value).toLocaleString('en-IN')}`, 'Amount']}
            contentStyle={{
              backgroundColor: '#0f172a',
              borderColor: '#1e293b',
              borderRadius: '0.75rem',
              color: '#fff',
              fontSize: '12px',
            }}
          />
          <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}
