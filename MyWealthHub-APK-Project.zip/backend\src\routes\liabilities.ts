// ============================================================================
// My Wealth Hub — Liabilities Routes
// ============================================================================

import { Router, Response } from 'express';
import { getDb } from '../database';
import { AuthenticatedRequest, rupeesToPaise } from '../types';

const router = Router();

// List all liabilities
router.get('/', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const db = getDb();
  const liabilities = db
    .prepare('SELECT * FROM liabilities WHERE user_id = ? ORDER BY outstanding_amount DESC')
    .all(userId);
  res.json({ success: true, data: liabilities });
});

// Liabilities summary
router.get('/summary', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const db = getDb();

  const grouped = db
    .prepare(
      `SELECT type, COUNT(*) as count, SUM(outstanding_amount) as total_outstanding, SUM(COALESCE(emi_amount, 0)) as total_emi
       FROM liabilities
       WHERE user_id = ?
       GROUP BY type
       ORDER BY total_outstanding DESC`
    )
    .all(userId);

  const totals = db
    .prepare(
      `SELECT 
         COALESCE(SUM(principal_amount), 0) as total_principal,
         COALESCE(SUM(outstanding_amount), 0) as total_outstanding,
         COALESCE(SUM(emi_amount), 0) as total_monthly_emi
       FROM liabilities
       WHERE user_id = ?`
    )
    .get(userId) as any;

  res.json({
    success: true,
    data: {
      grouped,
      totalPrincipal: totals.total_principal,
      totalOutstanding: totals.total_outstanding,
      totalMonthlyEMI: totals.total_monthly_emi,
    },
  });
});

// Create liability
router.post('/', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const {
    name,
    type,
    institution,
    principalAmount = 0,
    outstandingAmount = 0,
    interestRate,
    emiAmount,
    startDate,
    endDate,
    nextEmiDate,
    notes,
  } = req.body;

  if (!name || !type) {
    res.status(400).json({ success: false, error: 'Name and type are required' });
    return;
  }

  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO liabilities (
      user_id, name, type, institution, principal_amount, outstanding_amount,
      interest_rate, emi_amount, start_date, end_date, next_emi_date, notes
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const result = stmt.run(
    userId,
    name,
    type,
    institution || null,
    rupeesToPaise(Number(principalAmount)),
    rupeesToPaise(Number(outstandingAmount)),
    interestRate || null,
    emiAmount !== undefined && emiAmount !== null ? rupeesToPaise(Number(emiAmount)) : null,
    startDate || null,
    endDate || null,
    nextEmiDate || null,
    notes || null
  );

  const created = db.prepare('SELECT * FROM liabilities WHERE id = ?').get(result.lastInsertRowid);
  res.status(201).json({ success: true, data: created });
});

// Update liability
router.put('/:id', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const db = getDb();
  const existing = db.prepare('SELECT * FROM liabilities WHERE id = ? AND user_id = ?').get(req.params.id, userId) as any;

  if (!existing) {
    res.status(404).json({ success: false, error: 'Liability not found' });
    return;
  }

  const {
    name = existing.name,
    type = existing.type,
    institution = existing.institution,
    principalAmount,
    outstandingAmount,
    interestRate = existing.interest_rate,
    emiAmount,
    startDate = existing.start_date,
    endDate = existing.end_date,
    nextEmiDate = existing.next_emi_date,
    notes = existing.notes,
  } = req.body;

  const princ = principalAmount !== undefined ? rupeesToPaise(Number(principalAmount)) : existing.principal_amount;
  const outst = outstandingAmount !== undefined ? rupeesToPaise(Number(outstandingAmount)) : existing.outstanding_amount;
  const emi = emiAmount !== undefined && emiAmount !== null ? rupeesToPaise(Number(emiAmount)) : existing.emi_amount;

  db.prepare(`
    UPDATE liabilities
    SET name = ?, type = ?, institution = ?, principal_amount = ?, outstanding_amount = ?,
        interest_rate = ?, emi_amount = ?, start_date = ?, end_date = ?, next_emi_date = ?,
        notes = ?, updated_at = CURRENT_TIMESTAMP
    WHERE id = ? AND user_id = ?
  `).run(
    name,
    type,
    institution,
    princ,
    outst,
    interestRate,
    emi,
    startDate,
    endDate,
    nextEmiDate,
    notes,
    req.params.id,
    userId
  );

  const updated = db.prepare('SELECT * FROM liabilities WHERE id = ?').get(req.params.id);
  res.json({ success: true, data: updated });
});

// Delete liability
router.delete('/:id', (req: AuthenticatedRequest, res: Response): void => {
  const userId = req.user!.userId;
  const db = getDb();
  db.prepare('DELETE FROM liabilities WHERE id = ? AND user_id = ?').run(req.params.id, userId);
  res.json({ success: true, message: 'Liability deleted.' });
});

export default router;
