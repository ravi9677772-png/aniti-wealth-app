import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  Receipt,
  PieChart,
  Landmark,
  Target,
  Bot,
  FileSpreadsheet,
  Settings,
  UploadCloud,
  PlusCircle,
  ShieldCheck,
  LineChart,
} from 'lucide-react';

const NAV_ITEMS = [
  { path: '/', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/transactions', label: 'Transactions', icon: Receipt },
  { path: '/add-transaction', label: 'Add Entry', icon: PlusCircle },
  { path: '/budgets', label: 'Budgets', icon: PieChart },
  { path: '/insurance', label: 'Insurance & Dues', icon: ShieldCheck },
  { path: '/investments', label: 'Investments & Stocks', icon: LineChart },
  { path: '/assets', label: 'Assets & Debt', icon: Landmark },
  { path: '/goals', label: 'Goals', icon: Target },
  { path: '/assistant', label: 'AI Assistant', icon: Bot },
  { path: '/reports', label: 'Reports', icon: FileSpreadsheet },
  { path: '/import', label: 'Import Centre', icon: UploadCloud },
  { path: '/settings', label: 'Settings', icon: Settings },
];

export function Sidebar() {
  return (
    <aside className="hidden md:flex flex-col w-64 bg-slate-900 text-slate-300 border-r border-slate-800 p-4 shrink-0">
      {/* Brand */}
      <div className="flex items-center gap-3 px-3 py-4 mb-4">
        <div className="w-10 h-10 rounded-xl bg-teal-500 flex items-center justify-center text-white font-black text-xl shadow-lg shadow-teal-500/20">
          ₹
        </div>
        <div>
          <h2 className="text-lg font-bold text-white tracking-tight leading-none">
            My Wealth Hub
          </h2>
          <span className="text-xs text-teal-400 font-medium">India Private Suite</span>
        </div>
      </div>

      {/* Nav List */}
      <nav className="flex-1 space-y-1">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3.5 py-2.5 rounded-xl font-medium transition ${
                  isActive
                    ? 'bg-teal-500/10 text-teal-400 font-semibold'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                }`
              }
            >
              <Icon size={19} />
              <span>{item.label}</span>
            </NavLink>
          );
        })}
      </nav>

      {/* Footer Info */}
      <div className="pt-4 border-t border-slate-800/80 px-2 text-xs text-slate-500">
        <p>Private & Encrypted</p>
        <p className="mt-0.5">Asia/Kolkata (IST)</p>
      </div>
    </aside>
  );
}
