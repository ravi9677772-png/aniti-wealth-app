import React, { useState, useEffect } from 'react';
import { PlusCircle, PieChart, AlertTriangle, CheckCircle, TrendingUp, Calendar } from 'lucide-react';
import { budgetApi, categoryApi } from '../services/api';
import { Budget, Category } from '../types';
import { BudgetProgressBar } from '../components/BudgetProgressBar';
import { Modal } from '../components/common/Modal';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { EmptyState } from '../components/common/EmptyState';
import { formatINR } from '../hooks/useCurrency';

export function BudgetsPage() {
  const [budgets, setBudgets] = useState<any[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form
  const [categoryId, setCategoryId] = useState('');
  const [amount, setAmount] = useState('');
  const [period, setPeriod] = useState('monthly');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadBudgets = async () => {
    try {
      setLoading(true);
      const [bRes, cRes] = await Promise.all([
        budgetApi.getBudgets(),
        categoryApi.getCategories('expense'),
      ]);
      setBudgets(bRes || []);
      setCategories(cRes || []);
    } catch (err) {
      console.error('Failed to load budgets:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadBudgets();
  }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!categoryId || !amount || parseFloat(amount) <= 0) {
      setError('Please select a category and enter a valid budget amount.');
      return;
    }

    setSaving(true);
    setError(null);

    try {
      await budgetApi.createBudget({
        categoryId: Number(categoryId),
        amount: parseFloat(amount),
        period: period as any,
      });
      setIsModalOpen(false);
      setCategoryId('');
      setAmount('');
      loadBudgets();
    } catch (err: any) {
      setError(err?.response?.data?.error || 'Failed to create budget.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!window.confirm('Delete this budget limit?')) return;
    try {
      await budgetApi.deleteBudget(id);
      loadBudgets();
    } catch (err) {
      console.error(err);
    }
  };

  const totalBudgetPaise = budgets.reduce((acc, b) => acc + (b.amount || 0), 0);
  const totalSpentPaise = budgets.reduce((acc, b) => acc + (b.spent_amount || 0), 0);
  const overallPct = totalBudgetPaise > 0 ? Math.round((totalSpentPaise / totalBudgetPaise) * 100) : 0;

  return (
    <div className="space-y-6">
      {/* Overview Card */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-5">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-xs font-bold text-teal-600 dark:text-teal-400 uppercase tracking-wider">
            <PieChart size={16} />
            <span>Monthly Budget Cockpit</span>
          </div>
          <h2 className="text-xl md:text-2xl font-black text-slate-900 dark:text-white">
            Overall Utilization: {overallPct}%
          </h2>
          <p className="text-xs text-slate-500 font-mono">
            Spent {formatINR(totalSpentPaise)} of {formatINR(totalBudgetPaise)} allocated
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="px-5 py-3 rounded-xl bg-teal-500 hover:bg-teal-600 text-white font-bold text-sm flex items-center gap-2 shadow-md shadow-teal-500/20 transition self-start md:self-auto"
        >
          <PlusCircle size={18} />
          <span>New Budget Limit</span>
        </button>
      </div>

      {/* Budget Grid */}
      {loading ? (
        <LoadingSpinner message="Calculating category utilization..." />
      ) : budgets.length === 0 ? (
        <EmptyState
          icon={PieChart}
          title="No Budgets Defined"
          description="Setting budget limits helps you curb discretionary spending and boost your monthly investible surplus."
          actionText="Create First Budget"
          onAction={() => setIsModalOpen(true)}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {budgets.map((b) => (
            <div key={b.id} className="relative group">
              <BudgetProgressBar
                categoryName={b.category_name}
                categoryIcon={b.category_icon}
                budgetAmount={b.amount}
                spentAmount={b.spent_amount || 0}
                remainingAmount={b.remaining_amount || 0}
                utilizationPercent={b.utilization_percent || 0}
              />
              <button
                onClick={() => handleDelete(b.id)}
                className="absolute top-3 right-3 text-xs text-slate-400 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition p-1"
                title="Delete budget"
              >
                ✕
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Create Modal */}
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Set Budget Limit">
        <form onSubmit={handleCreate} className="space-y-4">
          {error && (
            <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-xs font-semibold text-rose-600">
              {error}
            </div>
          )}

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">
              Expense Category
            </label>
            <select
              value={categoryId}
              onChange={(e) => setCategoryId(e.target.value)}
              required
              className="select-field text-sm rounded-xl"
            >
              <option value="">Select Category</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.icon || '📁'} {c.name}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">
              Monthly Limit (₹)
            </label>
            <input
              type="number"
              step="any"
              required
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="e.g. 10000"
              className="input-field text-sm rounded-xl"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">
              Period
            </label>
            <select
              value={period}
              onChange={(e) => setPeriod(e.target.value)}
              className="select-field text-sm rounded-xl"
            >
              <option value="monthly">Monthly</option>
              <option value="yearly">Yearly</option>
            </select>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={saving}
              className="w-full py-3 rounded-xl bg-teal-500 hover:bg-teal-600 text-white font-bold text-sm transition shadow-md disabled:opacity-50"
            >
              {saving ? 'Saving...' : 'Set Budget Limit'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
